package ru.example.harvesterfree

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Log
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import ru.example.harvesterfree.scanner.CameraBarcodeScanner
import ru.example.harvesterfree.scanner.HardwareScannerManager
import ru.example.harvesterfree.util.AppLog
import ru.example.harvesterfree.ui.MainViewModel
import ru.example.harvesterfree.ui.UiState
import ru.example.harvesterfree.ui.components.CreateProductDialog
import ru.example.harvesterfree.ui.components.QuantitySerialsDialog
import ru.example.harvesterfree.data.model.requiresFactorySerials
import ru.example.harvesterfree.ui.screens.DocumentScreen
import ru.example.harvesterfree.ui.screens.DocumentsListScreen
import ru.example.harvesterfree.ui.screens.NomenclatureScreen
import ru.example.harvesterfree.ui.screens.SettingsScreen
import ru.example.harvesterfree.ui.theme.NEOTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var hardwareScanner: HardwareScannerManager? = null

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, "Нужно разрешение камеры", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Без soft-keyboard
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermission.launch(Manifest.permission.CAMERA)
        }

        // Доступ к /storage/NEO на Android 11+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:$packageName")
                        }
                    )
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    } catch (_: Exception) {}
                }
            }
        }

        AppLog.init(this, viewModel.settings.enableLogging)
        AppLog.i("MainActivity", "onCreate package=$packageName")

        hardwareScanner = HardwareScannerManager(this) { barcode ->
            Log.i("MainActivity", "scan: $barcode")
            runOnUiThread { viewModel.onBarcodeScanned(barcode) }
        }
        hardwareScanner?.start()

        setContent {
            NEOTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val uiState by viewModel.uiState.collectAsState()
                    val documents by viewModel.documents.collectAsState()
                    val currentDoc by viewModel.currentDocument.collectAsState()
                    val pending by viewModel.pendingProduct.collectAsState()
                    val unknown by viewModel.unknownBarcode.collectAsState()
                    val lastSerial by viewModel.lastSerial.collectAsState()
                    val lastMark by viewModel.lastMark.collectAsState()
                    val message by viewModel.message.collectAsState()
                    val productCount by viewModel.productCount.collectAsState()
                    val organizations by viewModel.organizations.collectAsState()
                    val warehouses by viewModel.warehouses.collectAsState()
                    val activeLineIdForSerials by viewModel.activeLineIdForSerials.collectAsState()
                    val products by viewModel.products.collectAsState()

                    LaunchedEffect(message) {
                        message?.let { msg ->
                            val isError = msg.startsWith("Ошибка", ignoreCase = true) ||
                                msg.contains("ошибка", ignoreCase = true) ||
                                msg.contains("FTP ошибка", ignoreCase = true) ||
                                msg.contains("не найден", ignoreCase = true) ||
                                msg.contains("Нет связи", ignoreCase = true)
                            val duration = if (isError) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
                            Toast.makeText(this@MainActivity, msg, duration).show()
                            viewModel.clearMessage()
                        }
                    }

                    when (uiState) {
                        is UiState.List -> DocumentsListScreen(
                                configId = viewModel.settings.configId,
                            documents = documents,
                            onOpenDocument = viewModel::openDocument,
                            onCreateDocument = viewModel::createDocument,
                            onDeleteDocument = viewModel::deleteDocument,
                            onOpenSettings = viewModel::openSettings,
                            onOpenNomenclature = viewModel::openNomenclature,
                            onExportAll = viewModel::exportAllDocuments
                        )

                        is UiState.Document -> {
                            currentDoc?.let { doc ->
                                DocumentScreen(
                                    document = doc,
                                    settings = viewModel.settings,
                                    organizations = organizations,
                                    warehouses = warehouses,
                                    onBack = viewModel::closeDocument,
                                    onScanClick = viewModel::startScanning,
                                    onDeleteLine = viewModel::deleteLine,
                                    onDeleteSerial = viewModel::deleteSerialFromCollection,
                                    onPoolNameChange = viewModel::updateSerialPoolName,
                                    onOrganizationChange = viewModel::updateDocumentOrganization,
                                    onWarehouseChange = viewModel::updateDocumentWarehouse,
                                    activeLineIdForSerials = activeLineIdForSerials,
                                    onSelectLineForSerials = viewModel::selectLineForSerials,
                                    onSave = viewModel::saveCurrent,
                                    onExport = viewModel::exportCurrent
                                )
                            }
                            unknown?.let { barcode ->
                                if (pending == null) {
                                    CreateProductDialog(
                                        barcode = barcode,
                                        enableMarking = viewModel.settings.enableMarking,
                                        onSave = viewModel::onProductCreated,
                                        onDismiss = viewModel::dismissUnknown
                                    )
                                }
                            }
                            pending?.let { p ->
                                QuantitySerialsDialog(
                                    productName = p.name,
                                    barcode = p.barcode,
                                    isMarked = p.isMarked && viewModel.settings.enableMarking,
                                    enableFactorySerial = viewModel.settings.enableFactorySerial
                                        || (currentDoc?.type?.requiresFactorySerials() == true),
                                    externalSerial = lastSerial,
                                    externalMark = lastMark,
                                    onExternalConsumed = viewModel::clearLastExternal,
                                    onConfirm = { qty, serials, marks ->
                                        viewModel.confirmLine(qty, serials, marks)
                                    },
                                    onDismiss = viewModel::dismissPending,
                                    onScanSerialOrMark = viewModel::startScanningSerial
                                )
                            }
                        }

                        is UiState.Scanning -> CameraBarcodeScanner(
                            onBarcodeDetected = { code -> viewModel.onBarcodeScanned(code) }
                        )

                        is UiState.Settings -> SettingsScreen(
                            settings = viewModel.settings,
                            productCount = productCount,
                            organizations = organizations,
                            warehouses = warehouses,
                            exchangePath = viewModel.exchangeFolderPath(),
                            onBack = viewModel::closeSettings,
                            onImportNomenclature = viewModel::importNomenclature,
                            onExportLogs = { viewModel.exportLogs(this@MainActivity) },
                            onFtpTest = viewModel::ftpTest,
                            onEnsureExchangeFolder = {
                                val path = viewModel.ensureExchangeFolder()
                                Toast.makeText(this@MainActivity, "Папка:\n$path", Toast.LENGTH_LONG).show()
                            },
                            onSave = {
                                // setEnabled пишет файл в фоне — не блокирует UI
                                AppLog.setEnabled(this@MainActivity, viewModel.settings.enableLogging)
                                Toast.makeText(
                                    this@MainActivity,
                                    "Настройки сохранены",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )

                        is UiState.Nomenclature -> NomenclatureScreen(
                            products = products,
                            onSearch = viewModel::loadProducts,
                            onSave = viewModel::saveProductEdit,
                            onDelete = viewModel::deleteProduct,
                            onBack = viewModel::closeNomenclature
                        )
                    }
                }
            }
        }
    }

    /** HID-сканер без soft-keyboard */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val wedge = hardwareScanner?.keyWedge
        if (wedge != null && wedge.onKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        hardwareScanner?.start()
    }

    override fun onDestroy() {
        hardwareScanner?.stop()
        hardwareScanner = null
        super.onDestroy()
    }
}
