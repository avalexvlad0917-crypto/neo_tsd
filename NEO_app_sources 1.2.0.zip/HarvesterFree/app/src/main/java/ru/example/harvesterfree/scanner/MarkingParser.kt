package ru.example.harvesterfree.scanner

import ru.example.harvesterfree.data.model.CodeType
import ru.example.harvesterfree.data.model.ParsedCode

/**
 * Парсер кодов маркировки «Честный ЗНАК» (DataMatrix GS1).
 *
 * Типичный КМ:
 *   01 + GTIN(14) + 21 + SERIAL(до 20) + 91/92/93... (криптохвост)
 *
 * Примеры:
 *   010460406000000021N4N57RSCBU36G
 *   0104600439931256215QWERTY...
 *
 * Также обрабатывает обычные EAN-13/8.
 */
object MarkingParser {

    private val GS1_AI_01 = Regex("""^01(\d{14})""")
    private val GS1_AI_21 = Regex("""21([^\x1d\x1e]{1,20})""")

    fun parse(raw: String): ParsedCode {
        val code = raw.trim()
            .replace("\u001d", "")   // GS separator
            .replace("\u001e", "")

        // 1. DataMatrix маркировки (начинается с 01 + 14 цифр)
        if (code.startsWith("01") && code.length >= 16) {
            val gtinMatch = GS1_AI_01.find(code)
            if (gtinMatch != null) {
                val gtin = gtinMatch.groupValues[1]
                val afterGtin = code.substring(gtinMatch.range.last + 1)
                val serialMatch = GS1_AI_21.find(afterGtin)
                val serial = serialMatch?.groupValues?.get(1)

                // Полный КМ без крипто-хвоста (AI 91/92/93 обычно после серийника)
                val fullMark = if (serial != null) {
                    "01$gtin" + "21$serial"
                } else {
                    "01$gtin"
                }

                return ParsedCode(
                    raw = code,
                    type = CodeType.DATAMATRIX_MARK,
                    gtin = gtin,
                    serial = serial,
                    fullMark = fullMark
                )
            }
        }

        // 2. Обычный DataMatrix (не маркировка)
        if (code.length > 20 && !code.all { it.isDigit() }) {
            return ParsedCode(raw = code, type = CodeType.DATAMATRIX_OTHER)
        }

        // 3. EAN-13
        if (code.length == 13 && code.all { it.isDigit() }) {
            return ParsedCode(raw = code, type = CodeType.EAN13, gtin = "0$code")
        }

        // 4. EAN-8
        if (code.length == 8 && code.all { it.isDigit() }) {
            return ParsedCode(raw = code, type = CodeType.EAN8)
        }

        // 5. Code128 и прочее
        if (code.length in 4..48) {
            return ParsedCode(raw = code, type = CodeType.CODE128)
        }

        return ParsedCode(raw = code, type = CodeType.UNKNOWN)
    }

    /** Нормализует GTIN к 14 символам */
    fun normalizeGtin(gtinOrEan: String): String {
        val digits = gtinOrEan.filter { it.isDigit() }
        return when {
            digits.length == 14 -> digits
            digits.length == 13 -> "0$digits"
            digits.length == 12 -> "00$digits"
            digits.length == 8  -> digits.padStart(14, '0')
            else -> digits
        }
    }

    /** Извлекает штрихкод для поиска товара (GTIN без ведущих нулей или EAN) */
    fun barcodeForSearch(parsed: ParsedCode): String {
        return when (parsed.type) {
            CodeType.DATAMATRIX_MARK -> {
                // Ищем по GTIN без ведущего нуля (часто в 1С хранят EAN-13)
                val g = parsed.gtin ?: return parsed.raw
                if (g.startsWith("0") && g.length == 14) g.substring(1) else g
            }
            else -> parsed.raw
        }
    }
}
