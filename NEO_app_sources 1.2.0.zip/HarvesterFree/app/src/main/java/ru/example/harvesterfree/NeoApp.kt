package ru.example.harvesterfree

import android.app.Application
import ru.example.harvesterfree.data.SettingsRepository
import ru.example.harvesterfree.util.AppLog

class NeoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            val settings = SettingsRepository(this)
            AppLog.init(this, settings.enableLogging)
        } catch (e: Exception) {
            android.util.Log.e("NeoApp", "init: ${e.message}", e)
        }
    }
}
