package ru.example.harvesterfree.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// NEO industrial palette: deep navy + amber accent
private val NeoPrimary = Color(0xFF1B4F72)
private val NeoOnPrimary = Color(0xFFFFFFFF)
private val NeoSecondary = Color(0xFFF39C12)
private val NeoOnSecondary = Color(0xFF1A1A1A)
private val NeoBackground = Color(0xFFEEF2F6)
private val NeoSurface = Color(0xFFFFFFFF)
private val NeoTertiary = Color(0xFF16A085)
private val NeoError = Color(0xFFC0392B)

private val NeoColorScheme = lightColorScheme(
    primary = NeoPrimary,
    onPrimary = NeoOnPrimary,
    secondary = NeoSecondary,
    onSecondary = NeoOnSecondary,
    tertiary = NeoTertiary,
    background = NeoBackground,
    surface = NeoSurface,
    surfaceVariant = Color(0xFFE3E9F0),
    onSurface = Color(0xFF1A2332),
    onSurfaceVariant = Color(0xFF5A6A7A),
    outline = Color(0xFFB0BEC5),
    error = NeoError
)

@Composable
fun NEOTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NeoColorScheme,
        typography = Typography(),
        content = content
    )
}

// alias
@Composable
fun NeoTheme(content: @Composable () -> Unit) = NEOTheme(content)
