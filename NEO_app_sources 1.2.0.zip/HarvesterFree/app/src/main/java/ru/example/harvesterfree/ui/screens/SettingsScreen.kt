package ru.example.harvesterfree.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.example.harvesterfree.data.SettingsRepository
import ru.example.harvesterfree.data.model.DocumentColumn
import ru.example.harvesterfree.data.model.Organization
import ru.example.harvesterfree.data.model.Warehouse

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: SettingsRepository,
    productCount: Int,
    exchangePath: String = "",
    organizations: List<Organization> = emptyList(),
    warehouses: List<Warehouse> = emptyList(),
    onBack: () -> Unit,
    onImportNomenclature: () -> Unit,
    onEnsureExchangeFolder: () -> Unit = {},
    onFtpTest: () -> Unit = {},
    onExportLogs: () -> Unit = {},
    onSave: () -> Unit
) {
    var enableFactorySerial by remember { mutableStateOf(settings.enableFactorySerial) }
    var enableMarking by remember { mutableStateOf(settings.enableMarking) }
    var enableLogging by remember { mutableStateOf(settings.enableLogging) }
    var visibleCols by remember { mutableStateOf(settings.visibleColumns) }

    var ftpHost by remember { mutableStateOf(settings.ftpHost) }
    var ftpPort by remember { mutableStateOf(settings.ftpPort.toString()) }
    var ftpUser by remember { mutableStateOf(settings.ftpUser) }
    var ftpPassword by remember { mutableStateOf(settings.ftpPassword) }
    var ftpPassive by remember { mutableStateOf(settings.ftpPassive) }
    var ftpRemotePath by remember { mutableStateOf(settings.ftpRemotePath) }

    var defaultOrgId by remember { mutableStateOf(settings.defaultOrganizationId) }
    var defaultOrgName by remember { mutableStateOf(settings.defaultOrganizationName) }
    var defaultWhId by remember { mutableStateOf(settings.defaultWarehouseId) }
    var defaultWhName by remember { mutableStateOf(settings.defaultWarehouseName) }
    var orgMenu by remember { mutableStateOf(false) }
    var whMenu by remember { mutableStateOf(false) }

    fun writePrefs() {
        settings.enableFactorySerial = enableFactorySerial
        settings.enableMarking = enableMarking
        settings.enableLogging = enableLogging
        settings.visibleColumns = visibleCols
        settings.ftpHost = ftpHost.trim()
        settings.ftpPort = ftpPort.toIntOrNull() ?: 21
        settings.ftpUser = ftpUser.trim()
        settings.ftpPassword = ftpPassword
        settings.ftpPassive = ftpPassive
        settings.ftpRemotePath = ftpRemotePath.trim()
        settings.defaultOrganizationId = defaultOrgId
        settings.defaultOrganizationName = defaultOrgName
        settings.defaultWarehouseId = defaultWhId
        settings.defaultWarehouseName = defaultWhName
        settings.exchangeMode = "file"
        settings.ftpAutoSync = true
    }

    fun persist() {
        writePrefs()
        onSave()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    TextButton(onClick = { persist() }) {
                        Text("Сохранить", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Обмен с 1С", style = MaterialTheme.typography.titleMedium)
            Text(
                "Номенклатура: $productCount · Орг: ${organizations.size} · Склады: ${warehouses.size}",
                style = MaterialTheme.typography.bodyMedium
            )
            val cfg = settings.configId.ifBlank { "не задан" }
            Text(
                "Конфигурация 1С (configId): $cfg",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
            Button(onClick = onImportNomenclature, modifier = Modifier.fillMaxWidth()) {
                Text("Загрузить с 1С")
            }
            Text(
                "Скачивает nomenclature.json, catalogs.json (организации/склады) и documents_* с FTP (to_tsd).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()

            Text("По умолчанию в новых документах", style = MaterialTheme.typography.titleMedium)
            Text(
                "Можно оставить пустым. В документе значения можно сменить.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            ExposedDropdownMenuBox(expanded = orgMenu, onExpandedChange = { orgMenu = it }) {
                OutlinedTextField(
                    value = defaultOrgName.ifBlank { "— не выбрана —" },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Организация") },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = orgMenu) }
                )
                ExposedDropdownMenu(expanded = orgMenu, onDismissRequest = { orgMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("— не выбрана —") },
                        onClick = {
                            defaultOrgId = ""
                            defaultOrgName = ""
                            orgMenu = false
                        }
                    )
                    organizations.forEach { o ->
                        DropdownMenuItem(
                            text = { Text(o.name) },
                            onClick = {
                                defaultOrgId = o.id
                                defaultOrgName = o.name
                                orgMenu = false
                            }
                        )
                    }
                }
            }
            ExposedDropdownMenuBox(expanded = whMenu, onExpandedChange = { whMenu = it }) {
                OutlinedTextField(
                    value = defaultWhName.ifBlank { "— не выбран —" },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Склад") },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = whMenu) }
                )
                ExposedDropdownMenu(expanded = whMenu, onDismissRequest = { whMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("— не выбран —") },
                        onClick = {
                            defaultWhId = ""
                            defaultWhName = ""
                            whMenu = false
                        }
                    )
                    warehouses.forEach { w ->
                        DropdownMenuItem(
                            text = { Text(w.name) },
                            onClick = {
                                defaultWhId = w.id
                                defaultWhName = w.name
                                whMenu = false
                            }
                        )
                    }
                }
            }

            HorizontalDivider()

            Text("Сканирование", style = MaterialTheme.typography.titleMedium)
            SettingSwitchCard(
                title = "Ввод заводского номера",
                subtitle = "Запрос серийных / заводских номеров по количеству",
                checked = enableFactorySerial,
                onCheckedChange = { enableFactorySerial = it }
            )
            SettingSwitchCard(
                title = "Маркировка (Честный ЗНАК)",
                subtitle = "Разбор DataMatrix / кодов маркировки",
                checked = enableMarking,
                onCheckedChange = { enableMarking = it }
            )
            SettingSwitchCard(
                title = "Подробный лог",
                subtitle = "Подробный neo.log в папку NEO",
                checked = enableLogging,
                onCheckedChange = { enableLogging = it }
            )
            Text(
                "Простой лог (neo_simple.log) пишется всегда и очищается раз в сутки.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onExportLogs,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Выгрузить логи")
            }

            HorizontalDivider()

            Text("Столбцы в документах", style = MaterialTheme.typography.titleMedium)
            Text(
                "Отметьте, какие поля показывать в строках документов",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            val colLabels = listOf(
                DocumentColumn.NAME to "Наименование",
                DocumentColumn.BARCODE to "Штрихкод",
                DocumentColumn.QUANTITY to "Количество",
                DocumentColumn.UNIT to "Ед. изм.",
                DocumentColumn.PRICE to "Стоимость (цена)",
                DocumentColumn.AMOUNT to "Сумма",
                DocumentColumn.SERIALS to "Серии / заводские №",
                DocumentColumn.MARKS to "Коды маркировки"
            )
            colLabels.forEach { (col, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = col in visibleCols,
                        onCheckedChange = { checked ->
                            visibleCols = if (checked) visibleCols + col else visibleCols - col
                        }
                    )
                    Text(label)
                }
            }

            HorizontalDivider()

            Text("FTP", style = MaterialTheme.typography.titleMedium)
            Text(
                "Обмен с 1С через FTP. При сохранении документа файлы уходят в from_tsd. Справочники и номенклатура — кнопкой «Загрузить с 1С» вверху.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = ftpHost,
                onValueChange = { ftpHost = it },
                label = { Text("Хост FTP") },
                placeholder = { Text("192.168.1.10") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ftpPort,
                onValueChange = { ftpPort = it.filter { ch -> ch.isDigit() }.take(5) },
                label = { Text("Порт сервера FTP (обычно 21)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ftpUser,
                onValueChange = { ftpUser = it },
                label = { Text("Логин") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ftpPassword,
                onValueChange = { ftpPassword = it },
                label = { Text("Пароль") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ftpRemotePath,
                onValueChange = { ftpRemotePath = it },
                label = { Text("Удалённый путь (корень обмена)") },
                placeholder = { Text("пусто, если home FTP = папка обмена") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            SettingSwitchCard(
                title = "Пассивный режим FTP",
                subtitle = "Рекомендуется (PASV)",
                checked = ftpPassive,
                onCheckedChange = { ftpPassive = it }
            )
            Button(
                onClick = {
                    writePrefs()
                    onFtpTest()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Проверить подключение")
            }

            HorizontalDivider()

            Text("Папка обмена", style = MaterialTheme.typography.titleMedium)
            if (exchangePath.isNotBlank()) {
                Text(
                    exchangePath,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Button(
                onClick = onEnsureExchangeFolder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Создать / показать папку обмена")
            }
            Text(
                "Device ID: ${settings.deviceId}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SettingSwitchCard(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
