package ru.example.harvesterfree.data

import android.content.Context
import android.content.SharedPreferences
import ru.example.harvesterfree.data.model.DocumentColumn

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("neo_settings", Context.MODE_PRIVATE)

    var httpBaseUrl: String
        get() = prefs.getString(KEY_HTTP_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_HTTP_URL, value.trim().trimEnd('/')).apply()

    var httpLogin: String
        get() = prefs.getString(KEY_HTTP_LOGIN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_HTTP_LOGIN, value).apply()

    var httpPassword: String
        get() = prefs.getString(KEY_HTTP_PASSWORD, "") ?: ""
        set(value) = prefs.edit().putString(KEY_HTTP_PASSWORD, value).apply()

    var exchangeMode: String
        get() = prefs.getString(KEY_EXCHANGE_MODE, "file") ?: "file"
        set(value) = prefs.edit().putString(KEY_EXCHANGE_MODE, value).apply()

    var sharedFolderUri: String
        get() = prefs.getString(KEY_SHARED_FOLDER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SHARED_FOLDER, value).apply()

    var deviceId: String
        get() {
            var id = prefs.getString(KEY_DEVICE_ID, null)
            if (id.isNullOrBlank()) {
                id = "neo-" + java.util.UUID.randomUUID().toString().take(8)
                prefs.edit().putString(KEY_DEVICE_ID, id).apply()
            }
            return id!!
        }
        set(value) = prefs.edit().putString(KEY_DEVICE_ID, value).apply()

    var enableFactorySerial: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_FACTORY_SERIAL, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_FACTORY_SERIAL, value).apply()

    var enableMarking: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_MARKING, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_MARKING, value).apply()

    /** Писать лог в /storage/.../NEO/neo.log */
    var enableLogging: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_LOGGING, false)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_LOGGING, value).apply()

    /** Видимые столбцы документа (CSV имён enum) */
    var visibleColumns: Set<DocumentColumn>
        get() {
            val raw = prefs.getString(KEY_VISIBLE_COLUMNS, null)
            if (raw.isNullOrBlank()) return defaultColumns()
            return raw.split(',')
                .mapNotNull { runCatching { DocumentColumn.valueOf(it.trim()) }.getOrNull() }
                .toSet()
                .ifEmpty { defaultColumns() }
        }
        set(value) {
            prefs.edit().putString(KEY_VISIBLE_COLUMNS, value.joinToString(",") { it.name }).apply()
        }

    fun isColumnVisible(col: DocumentColumn): Boolean = col in visibleColumns

    private fun defaultColumns(): Set<DocumentColumn> = setOf(
        DocumentColumn.NAME,
        DocumentColumn.BARCODE,
        DocumentColumn.QUANTITY,
        DocumentColumn.UNIT,
        DocumentColumn.PRICE,
        DocumentColumn.AMOUNT,
        DocumentColumn.SERIALS,
        DocumentColumn.MARKS
    )


    // --- FTP ---
    var ftpHost: String
        get() = prefs.getString(KEY_FTP_HOST, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FTP_HOST, value).apply()

    var ftpPort: Int
        get() = prefs.getInt(KEY_FTP_PORT, 21)
        set(value) = prefs.edit().putInt(KEY_FTP_PORT, value).apply()

    var ftpUser: String
        get() = prefs.getString(KEY_FTP_USER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FTP_USER, value).apply()

    var ftpPassword: String
        get() = prefs.getString(KEY_FTP_PASSWORD, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FTP_PASSWORD, value).apply()

    /** Пассивный режим (обычно нужен) */
    var ftpPassive: Boolean
        get() = prefs.getBoolean(KEY_FTP_PASSIVE, true)
        set(value) = prefs.edit().putBoolean(KEY_FTP_PASSIVE, value).apply()

    /** После выгрузки/перед загрузкой — обмен по FTP */
    var ftpAutoSync: Boolean
        get() = prefs.getBoolean(KEY_FTP_AUTO_SYNC, false)
        set(value) = prefs.edit().putBoolean(KEY_FTP_AUTO_SYNC, value).apply()

    /** Подкаталог на FTP (корень обмена), например /neo_tsd или пусто */
    var ftpRemotePath: String
        get() = prefs.getString(KEY_FTP_REMOTE_PATH, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FTP_REMOTE_PATH, value).apply()

    companion object {
        private const val KEY_HTTP_URL = "http_base_url"
        private const val KEY_HTTP_LOGIN = "http_login"
        private const val KEY_HTTP_PASSWORD = "http_password"
        private const val KEY_EXCHANGE_MODE = "exchange_mode"
        private const val KEY_SHARED_FOLDER = "shared_folder_uri"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_ENABLE_FACTORY_SERIAL = "enable_factory_serial"
        private const val KEY_ENABLE_MARKING = "enable_marking"
        private const val KEY_ENABLE_LOGGING = "enable_logging"
        private const val KEY_VISIBLE_COLUMNS = "visible_columns"
        private const val KEY_FTP_HOST = "ftp_host"
        private const val KEY_FTP_PORT = "ftp_port"
        private const val KEY_FTP_USER = "ftp_user"
        private const val KEY_FTP_PASSWORD = "ftp_password"
        private const val KEY_FTP_PASSIVE = "ftp_passive"
        private const val KEY_FTP_AUTO_SYNC = "ftp_auto_sync"
        private const val KEY_FTP_REMOTE_PATH = "ftp_remote_path"
    }

    var defaultOrganizationId: String
        get() = prefs.getString("default_org_id", "") ?: ""
        set(value) = prefs.edit().putString("default_org_id", value).apply()

    var defaultOrganizationName: String
        get() = prefs.getString("default_org_name", "") ?: ""
        set(value) = prefs.edit().putString("default_org_name", value).apply()

    var defaultWarehouseId: String
        get() = prefs.getString("default_wh_id", "") ?: ""
        set(value) = prefs.edit().putString("default_wh_id", value).apply()

    var defaultWarehouseName: String
        get() = prefs.getString("default_wh_name", "") ?: ""
        set(value) = prefs.edit().putString("default_wh_name", value).apply()

    /** Идентификатор конфигурации 1С из nomenclature/catalogs/documents (UT11, UNF, ERP, …). */
    var configId: String
        get() = prefs.getString("config_id", "") ?: ""
        set(value) = prefs.edit().putString("config_id", value).apply()

}
