package ru.example.harvesterfree.data.local

import android.content.Context
import androidx.room.*
import ru.example.harvesterfree.data.model.*

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1")
    suspend fun findByBarcode(barcode: String): Product?

    @Query("SELECT * FROM products WHERE gtin = :gtin LIMIT 1")
    suspend fun findByGtin(gtin: String): Product?

    @Query("SELECT * FROM products ORDER BY name")
    suspend fun getAll(): List<Product>

    @Query("SELECT * FROM products WHERE name LIKE '%' || :q || '%' OR barcode LIKE '%' || :q || '%' OR article LIKE '%' || :q || '%' ORDER BY name")
    suspend fun search(q: String): List<Product>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(product: Product)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(products: List<Product>)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM products")
    suspend fun clear()
}

@Dao
interface DocumentDao {
    @Transaction
    @Query("SELECT * FROM documents ORDER BY date DESC")
    suspend fun getAllWithLines(): List<DocumentWithLines>

    @Transaction
    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun getById(id: String): DocumentWithLines?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: DocumentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLines(lines: List<DocumentLineEntity>)

    @Query("DELETE FROM document_lines WHERE documentId = :documentId")
    suspend fun deleteLines(documentId: String)

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deleteDocument(id: String)

    @Query("UPDATE documents SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: DocumentStatus)
}

@Dao
interface CatalogDao {
    @Query("SELECT * FROM organizations ORDER BY name")
    suspend fun getOrganizations(): List<Organization>

    @Query("SELECT * FROM warehouses ORDER BY name")
    suspend fun getWarehouses(): List<Warehouse>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrganizations(items: List<Organization>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWarehouses(items: List<Warehouse>)

    @Query("DELETE FROM organizations")
    suspend fun clearOrganizations()

    @Query("DELETE FROM warehouses")
    suspend fun clearWarehouses()

    @Query("SELECT COUNT(*) FROM organizations")
    suspend fun countOrganizations(): Int

    @Query("SELECT COUNT(*) FROM warehouses")
    suspend fun countWarehouses(): Int
}

@Database(
    entities = [
        Product::class,
        DocumentEntity::class,
        DocumentLineEntity::class,
        Organization::class,
        Warehouse::class
    ],
    version = 5,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun documentDao(): DocumentDao
    abstract fun catalogDao(): CatalogDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "neo.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
