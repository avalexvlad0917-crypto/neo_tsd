package ru.example.harvesterfree.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import ru.example.harvesterfree.data.model.*

/**
 * Создание карточки номенклатуры, когда ШК не найден в базе.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateProductDialog(
    barcode: String,
    enableMarking: Boolean,
    onSave: (Product) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(NomenclatureKind.GOODS) }
    var markedType by remember { mutableStateOf(MarkedProductType.NONE) }
    var unit by remember { mutableStateOf("шт") }
    var vat by remember { mutableStateOf(VatRate.NO_VAT) }
    var kindExpanded by remember { mutableStateOf(false) }
    var markedExpanded by remember { mutableStateOf(false) }
    var vatExpanded by remember { mutableStateOf(false) }
    var unitExpanded by remember { mutableStateOf(false) }

    val units = listOf("шт", "кг", "л", "м", "уп", "кор")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = MaterialTheme.shapes.large
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Товар не найден", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Штрихкод отсутствует в справочнике. Заполните карточку номенклатуры.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = barcode,
                    onValueChange = {},
                    label = { Text("Штрихкод") },
                    readOnly = true,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Наименование *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Вид номенклатуры
                ExposedDropdownMenuBox(expanded = kindExpanded, onExpandedChange = { kindExpanded = it }) {
                    OutlinedTextField(
                        value = kind.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Вид номенклатуры") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(kindExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = kindExpanded, onDismissRequest = { kindExpanded = false }) {
                        NomenclatureKind.entries.forEach {
                            DropdownMenuItem(text = { Text(it.label) }, onClick = {
                                kind = it
                                kindExpanded = false
                            })
                        }
                    }
                }

                if (enableMarking) {
                    ExposedDropdownMenuBox(expanded = markedExpanded, onExpandedChange = { markedExpanded = it }) {
                        OutlinedTextField(
                            value = markedType.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Тип маркированной продукции") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(markedExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = markedExpanded, onDismissRequest = { markedExpanded = false }) {
                            MarkedProductType.entries.forEach {
                                DropdownMenuItem(text = { Text(it.label) }, onClick = {
                                    markedType = it
                                    markedExpanded = false
                                })
                            }
                        }
                    }
                }

                ExposedDropdownMenuBox(expanded = unitExpanded, onExpandedChange = { unitExpanded = it }) {
                    OutlinedTextField(
                        value = unit,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Единица измерения") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(unitExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = unitExpanded, onDismissRequest = { unitExpanded = false }) {
                        units.forEach {
                            DropdownMenuItem(text = { Text(it) }, onClick = {
                                unit = it
                                unitExpanded = false
                            })
                        }
                    }
                }

                ExposedDropdownMenuBox(expanded = vatExpanded, onExpandedChange = { vatExpanded = it }) {
                    OutlinedTextField(
                        value = vat.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Ставка НДС") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(vatExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = vatExpanded, onDismissRequest = { vatExpanded = false }) {
                        VatRate.entries.forEach {
                            DropdownMenuItem(text = { Text(it.label) }, onClick = {
                                vat = it
                                vatExpanded = false
                            })
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Отмена") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isBlank()) return@Button
                            val isMarked = enableMarking && markedType != MarkedProductType.NONE
                            onSave(
                                Product(
                                    barcode = barcode,
                                    name = name.trim(),
                                    unit = unit,
                                    kind = kind.name,
                                    markedType = if (enableMarking) markedType.name else MarkedProductType.NONE.name,
                                    isMarked = isMarked,
                                    vatRate = vat.label,
                                    hasSerials = false
                                )
                            )
                        },
                        enabled = name.isNotBlank()
                    ) { Text("Сохранить и добавить") }
                }
            }
        }
    }
}
