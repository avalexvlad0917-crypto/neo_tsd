package ru.example.harvesterfree.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.example.harvesterfree.data.SettingsRepository
import ru.example.harvesterfree.util.AppLog
import ru.example.harvesterfree.data.local.AppDatabase
import ru.example.harvesterfree.data.model.*
import ru.example.harvesterfree.data.model.requiresFactorySerials
import ru.example.harvesterfree.data.repository.DocumentRepository
import ru.example.harvesterfree.scanner.MarkingParser
import ru.example.harvesterfree.sync.SyncManager
import java.io.File
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*

sealed class UiState {
    object List : UiState()
    data class Document(val doc: ru.example.harvesterfree.data.model.Document) : UiState()
    object Scanning : UiState()
    object Settings : UiState()
    object Nomenclature : UiState()
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    private val repository = DocumentRepository(db)
    val settings = SettingsRepository(app)
    private val syncManager = SyncManager(app, repository, settings)

    private val _documents = MutableStateFlow<List<Document>>(emptyList())
    val documents: StateFlow<List<Document>> = _documents.asStateFlow()

    private val _currentDocument = MutableStateFlow<Document?>(null)
    val currentDocument: StateFlow<Document?> = _currentDocument.asStateFlow()

    private val _uiState = MutableStateFlow<UiState>(UiState.List)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    data class PendingProduct(
        val barcode: String,
        val name: String,
        val productId: String?,
        val isMarked: Boolean = false,
        val unit: String = "шт",
        val price: BigDecimal = BigDecimal.ZERO
    )

    private val _pendingProduct = MutableStateFlow<PendingProduct?>(null)
    val pendingProduct: StateFlow<PendingProduct?> = _pendingProduct.asStateFlow()

    private val _unknownBarcode = MutableStateFlow<String?>(null)
    val unknownBarcode: StateFlow<String?> = _unknownBarcode.asStateFlow()

    private val _scanningSerial = MutableStateFlow(false)
    val scanningSerial: StateFlow<Boolean> = _scanningSerial.asStateFlow()

    /** Строка документа, в которую сейчас вводятся заводские номера (сканом). */
    private val _activeLineIdForSerials = MutableStateFlow<String?>(null)
    val activeLineIdForSerials: StateFlow<String?> = _activeLineIdForSerials.asStateFlow()

    private val _activePoolName = MutableStateFlow("")
    val activePoolName: StateFlow<String> = _activePoolName.asStateFlow()

    private val _lastSerial = MutableStateFlow<String?>(null)
    private val _extraSerialsFromQr = MutableStateFlow<List<String>>(emptyList())
    /** Защита от двойного срабатывания сканера (один и тот же код подряд). */
    @Volatile private var lastSerialScanCode: String = ""
    @Volatile private var lastSerialScanAt: Long = 0L
    val lastSerial: StateFlow<String?> = _lastSerial.asStateFlow()

    private val _lastMark = MutableStateFlow<String?>(null)
    val lastMark: StateFlow<String?> = _lastMark.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _productCount = MutableStateFlow(0)
    val productCount: StateFlow<Int> = _productCount.asStateFlow()

    private val _organizations = MutableStateFlow<List<ru.example.harvesterfree.data.model.Organization>>(emptyList())
    val organizations: StateFlow<List<ru.example.harvesterfree.data.model.Organization>> = _organizations.asStateFlow()

    private val _warehouses = MutableStateFlow<List<ru.example.harvesterfree.data.model.Warehouse>>(emptyList())
    val warehouses: StateFlow<List<ru.example.harvesterfree.data.model.Warehouse>> = _warehouses.asStateFlow()


    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    init {
        // при старте — подтянуть задания с FTP
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { syncManager.pullFromServer() }
                refreshList()
                refreshProductCount()
            }
        }

        refreshList()
        refreshProductCount()
        refreshCatalogs()
    }

    fun refreshList() {
        viewModelScope.launch { _documents.value = repository.getAllDocuments() }
    }

    private fun refreshProductCount() {
        viewModelScope.launch { _productCount.value = repository.productCount() }
    }

    fun loadProducts(query: String = "") {
        viewModelScope.launch {
            _products.value = repository.searchProducts(query)
        }
    }

    fun createDocument(type: DocumentType) {
        val prefix = when (type) {
            DocumentType.CUSTOMER_ORDER -> "ORD"
            DocumentType.SERIAL_COLLECTION -> "SER"
            DocumentType.GOODS_RECEIPT_ORDER -> "PRO"
            DocumentType.GOODS_ISSUE_ORDER -> "RO"
            DocumentType.MOVEMENT_ORDER -> "PO"
            DocumentType.SURPLUS_ORDER -> "IZL"
            DocumentType.SHORTAGE_ORDER -> "NED"
            DocumentType.DAMAGE_ORDER -> "POR"
            DocumentType.PURCHASE_ORDER -> "ZP"
            DocumentType.MOVEMENT_REQUEST -> "ZN"
            else -> type.name.take(3)
        }
        val number = "$prefix-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date())}"
        val doc = Document(
            type = type,
            number = number,
            organizationId = settings.defaultOrganizationId.ifBlank { null },
            organizationName = settings.defaultOrganizationName.ifBlank { null },
            warehouseId = settings.defaultWarehouseId.ifBlank { null },
            warehouseName = settings.defaultWarehouseName.ifBlank { null }
        )
        viewModelScope.launch {
            repository.saveDocument(doc)
            _currentDocument.value = doc
            if (type == DocumentType.SERIAL_COLLECTION) _activePoolName.value = ""
            _uiState.value = UiState.Document(doc)
            refreshList()
            runCatching {
                withContext(Dispatchers.IO) { syncManager.pullFromServer() }
            }
        }
    }

    fun openDocument(id: String) {
        viewModelScope.launch {
            refreshCatalogs()
            repository.getDocument(id)?.let {
                _currentDocument.value = it
                _uiState.value = UiState.Document(it)
            }
        }
    }

    fun closeDocument() {
        _currentDocument.value = null
        _pendingProduct.value = null
        _unknownBarcode.value = null
        _scanningSerial.value = false
        _activeLineIdForSerials.value = null
        _uiState.value = UiState.List
        refreshList()
        // фоном подтянуть документы из 1С
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { syncManager.pullFromServer() }
                refreshList()
            }
        }
    }


    fun updateDocumentOrganization(id: String?, name: String?) {
        val doc = _currentDocument.value ?: return
        val updated = doc.copy(
            organizationId = id,
            organizationName = name
        )
        _currentDocument.value = updated
        viewModelScope.launch { repository.saveDocument(updated) }
    }

    fun updateDocumentWarehouse(id: String?, name: String?) {
        val doc = _currentDocument.value ?: return
        val updated = doc.copy(
            warehouseId = id,
            warehouseName = name
        )
        _currentDocument.value = updated
        viewModelScope.launch { repository.saveDocument(updated) }
    }

    fun refreshCatalogs() {
        viewModelScope.launch {
            _organizations.value = repository.getOrganizations()
            _warehouses.value = repository.getWarehouses()
        }
    }

    fun openSettings() {
        refreshCatalogs()
        _uiState.value = UiState.Settings
    }
    fun closeSettings() { _uiState.value = UiState.List }

    fun openNomenclature() {
        loadProducts()
        _uiState.value = UiState.Nomenclature
    }

    fun closeNomenclature() { _uiState.value = UiState.List }

    fun startScanning() {
        if (_currentDocument.value == null) {
            _message.value = "Сначала откройте или создайте документ"
            return
        }
        _scanningSerial.value = false
        _uiState.value = UiState.Scanning
    }

    fun startScanningSerial() {
        // Явный режим ввода серии / КМ
        _scanningSerial.value = true
        _uiState.value = UiState.Scanning
    }

    /**
     * Единая точка входа для камеры и hardware-сканера.
     * ВАЖНО: если открыт диалог количества/серий — скан идёт в серию, НЕ в поиск ШК.
     */

    fun selectLineForSerials(lineId: String?) {
        _activeLineIdForSerials.value = lineId
        if (lineId != null) {
            _message.value = "Сканируйте заводские номера для выбранной позиции"
        }
    }

    
    private fun normalizeSerial(raw: String): String {
        return raw.trim().replace("\r", "").trim()
    }

    /** Разбор QR: каждая строка = отдельный заводской номер. */
    private fun serialTokens(raw: String): List<String> {
        return raw
            .split(Regex("[\r\n]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .flatMap { line ->
                when {
                    '	' in line -> line.split('	').map { it.trim() }
                    "  " in line -> line.split(Regex(" {2,}")).map { it.trim() }
                    else -> listOf(line)
                }
            }
            .map { normalizeSerial(it) }
            .filter { it.isNotEmpty() }
            .distinct()
    }

    fun addSerialToLine(lineId: String, serial: String) {
        addSerialsToLine(lineId, listOf(serial))
    }

    /**
     * Пакетное добавление серий (QR с несколькими номерами).
     * Один апдейт документа — без гонок и ложных «Уже есть» при серии сканов.
     */
    fun addSerialsToLine(lineId: String, serials: List<String>) {
        val doc = _currentDocument.value ?: return
        val codes = serials.map { normalizeSerial(it) }.filter { it.isNotEmpty() }.distinct()
        if (codes.isEmpty()) return

        val now = System.currentTimeMillis()
        if (codes.size == 1) {
            val c = codes[0]
            if (c == lastSerialScanCode && now - lastSerialScanAt < 400L) {
                return
            }
            lastSerialScanCode = c
            lastSerialScanAt = now
        }

        val target = doc.lines.find { it.id == lineId }
        if (target == null) {
            _message.value = "Строка не найдена"
            return
        }

        val ownerId = mutableMapOf<String, String>()
        for (line in doc.lines) {
            for (s in line.serials) {
                ownerId[normalizeSerial(s)] = line.id
            }
        }

        val toAdd = mutableListOf<String>()
        val moved = mutableListOf<String>()
        val alreadyHere = mutableListOf<String>()

        for (c in codes) {
            val owner = ownerId[c]
            when {
                owner == null -> toAdd.add(c)
                owner == lineId -> alreadyHere.add(c)
                else -> {
                    moved.add(c)
                    toAdd.add(c)
                }
            }
        }

        if (toAdd.isEmpty()) {
            _message.value = if (alreadyHere.isNotEmpty()) {
                "Уже в этой строке: ${alreadyHere.first()}"
            } else {
                "Нечего добавлять"
            }
            return
        }

        val moveSet = moved.toSet()
        val lines = doc.lines.map { line ->
            when {
                line.id == lineId -> {
                    val newSerials = (line.serials.map { normalizeSerial(it) } + toAdd).distinct()
                    val qty = BigDecimal(newSerials.size)
                    val amount = qty.multiply(line.price).setScale(2, RoundingMode.HALF_UP)
                    line.copy(serials = newSerials, quantity = qty, amount = amount)
                }
                moveSet.isNotEmpty() -> {
                    val filtered = line.serials.filter { normalizeSerial(it) !in moveSet }
                    if (filtered.size == line.serials.size) line
                    else {
                        val qty = BigDecimal(filtered.size)
                        val amount = qty.multiply(line.price).setScale(2, RoundingMode.HALF_UP)
                        line.copy(serials = filtered, quantity = qty, amount = amount)
                    }
                }
                else -> line
            }
        }

        val cleaned = lines.filter { line ->
            line.productName.isNotBlank() || line.barcode.isNotBlank() || line.serials.isNotEmpty()
        }

        val updated = doc.copy(lines = cleaned)
        _currentDocument.value = updated
        _uiState.value = UiState.Document(updated)
        viewModelScope.launch { repository.saveDocument(updated) }

        val n = cleaned.find { it.id == lineId }?.serials?.size ?: 0
        _message.value = buildString {
            when {
                toAdd.size == 1 && moved.isEmpty() -> append("+ ${toAdd[0]}")
                else -> append("+${toAdd.size}")
            }
            if (moved.isNotEmpty()) append(", перенос ${moved.size}")
            if (alreadyHere.isNotEmpty()) append(", уже было ${alreadyHere.size}")
            append(" · серий: $n")
        }
    }


    fun onBarcodeScanned(raw: String) {
        if (raw.isBlank()) return
        val code = raw.trim()
        val doc = _currentDocument.value
        if (doc == null) {
            _message.value = "Откройте документ перед сканированием"
            return
        }

        // === Документ «Сбор серийных номеров» ===
        if (doc.type == DocumentType.SERIAL_COLLECTION) {
            serialTokens(code).forEach { addSerialToCollection(it) }
            return
        }

        // === Ввод серий в выбранную позицию (пакетно из QR) ===
        val activeLineId = _activeLineIdForSerials.value
        if (activeLineId != null) {
            addSerialsToLine(activeLineId, serialTokens(code))
            return
        }

        val enableMarking = settings.enableMarking
        val parsed = if (enableMarking) MarkingParser.parse(code) else {
            ParsedCode(raw = code, type = CodeType.UNKNOWN)
        }

        // === Режим серии: кнопка «Сканировать серию» ИЛИ уже открыт диалог количества ===
        val treatAsSerial = _scanningSerial.value || _pendingProduct.value != null

        if (treatAsSerial) {
            when {
                enableMarking && parsed.type == CodeType.DATAMATRIX_MARK ->
                    _lastMark.value = parsed.fullMark ?: parsed.raw
                else -> {
                    val tokens = serialTokens(code)
                    if (tokens.size > 1) {
                        _lastSerial.value = tokens.first()
                        _extraSerialsFromQr.value = tokens.drop(1)
                        _message.value = "QR: ${tokens.size} номеров"
                    } else {
                        _lastSerial.value = tokens.firstOrNull() ?: normalizeSerial(code)
                    }
                                }
            }
            _scanningSerial.value = false
            _uiState.value = UiState.Document(doc)
            return
        }

        // === Обычный поиск товара по ШК ===
        viewModelScope.launch {
            val searchBarcode = if (enableMarking) {
                MarkingParser.barcodeForSearch(parsed)
            } else {
                code
            }

            var product = repository.findProduct(searchBarcode)
            if (product == null && enableMarking && parsed.gtin != null) {
                product = repository.findProductByGtin(parsed.gtin)
            }

            if (product == null) {
                _unknownBarcode.value = searchBarcode
                _pendingProduct.value = null
                _uiState.value = UiState.Document(doc)
                _message.value = "Штрихкод не найден в базе"
                return@launch
            }

            openQuantityDialog(product, parsed, enableMarking)
        }
    }

    private fun addSerialToCollection(serial: String) {
        val doc = _currentDocument.value ?: return
        val pool = _activePoolName.value.trim().ifBlank { "default" }
        val code = normalizeSerial(serial)
        if (code.isEmpty()) return

        if (doc.lines.any { line -> line.serials.any { normalizeSerial(it) == code } }) {
            _message.value = "Уже в документе: $code"
            return
        }

        val lines = doc.lines.toMutableList()
        val idx = lines.indexOfFirst { it.productName.equals(pool, ignoreCase = true) }
        if (idx >= 0) {
            val line = lines[idx]
            lines[idx] = line.copy(
                serials = line.serials + code,
                quantity = BigDecimal(line.serials.size + 1)
            )
        } else {
            lines.add(
                DocumentLine(
                    barcode = "",
                    productName = pool,
                    quantity = BigDecimal.ONE,
                    serials = listOf(code)
                )
            )
        }
        val updated = doc.copy(lines = lines)
        _currentDocument.value = updated
        _uiState.value = UiState.Document(updated)
        viewModelScope.launch { repository.saveDocument(updated) }
        _message.value = "+ $code → $pool"
    }

    private fun openQuantityDialog(product: Product, parsed: ParsedCode, enableMarking: Boolean) {
        val isMarked = enableMarking && (
            product.isMarked ||
            product.markedType != MarkedProductType.NONE.name ||
            parsed.type == CodeType.DATAMATRIX_MARK
        )
        val price = BigDecimal.valueOf(product.price ?: 0.0).setScale(2, RoundingMode.HALF_UP)

        _pendingProduct.value = PendingProduct(
            barcode = product.barcode,
            name = product.name,
            productId = product.id,
            isMarked = isMarked,
            unit = product.unit,
            price = price
        )

        if (enableMarking && parsed.type == CodeType.DATAMATRIX_MARK) {
            _lastMark.value = parsed.fullMark ?: parsed.raw
        }

        _currentDocument.value?.let {
            _uiState.value = UiState.Document(it)
        }
    }

    fun onProductCreated(product: Product) {
        viewModelScope.launch {
            repository.saveProduct(product)
            refreshProductCount()
            _unknownBarcode.value = null
            _message.value = "Товар «${product.name}» сохранён"
            loadProducts()

            val enableMarking = settings.enableMarking
            openQuantityDialog(
                product,
                ParsedCode(raw = product.barcode, type = CodeType.UNKNOWN),
                enableMarking
            )
        }
    }

    fun saveProductEdit(product: Product) {
        viewModelScope.launch {
            repository.saveProduct(product)
            refreshProductCount()
            loadProducts()
            _message.value = "Сохранено: ${product.name}"
        }
    }

    fun deleteProduct(id: String) {
        viewModelScope.launch {
            repository.deleteProduct(id)
            refreshProductCount()
            loadProducts()
            _message.value = "Товар удалён"
        }
    }

    fun dismissUnknown() {
        _unknownBarcode.value = null
    }

    fun confirmLine(quantity: BigDecimal, serials: List<String>, marks: List<String>) {
        val pending = _pendingProduct.value ?: return
        val doc = _currentDocument.value ?: return

        val price = pending.price
        val amount = quantity.multiply(price).setScale(2, RoundingMode.HALF_UP)

        val needSerials = settings.enableFactorySerial || doc.type.requiresFactorySerials()
        val allSerials = (serials + _extraSerialsFromQr.value)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
        _extraSerialsFromQr.value = emptyList()
        val line = DocumentLine(
            barcode = pending.barcode,
            productName = pending.name,
            quantity = quantity,
            unit = pending.unit,
            price = price,
            amount = amount,
            serials = if (needSerials) allSerials else emptyList(),
            marks = if (settings.enableMarking) marks else emptyList(),
            productId = pending.productId
        )

        val updated = doc.copy(lines = doc.lines + line)
        _currentDocument.value = updated
        _pendingProduct.value = null
        _lastSerial.value = null
        _lastMark.value = null

        viewModelScope.launch { repository.saveDocument(updated) }
    }

    fun dismissPending() {
        _pendingProduct.value = null
        _scanningSerial.value = false
        _lastSerial.value = null
        _lastMark.value = null
    }

    fun deleteLine(lineId: String) {
        val doc = _currentDocument.value ?: return
        val updated = doc.copy(lines = doc.lines.filter { it.id != lineId })
        _currentDocument.value = updated
        viewModelScope.launch { repository.saveDocument(updated) }
    }

    fun deleteSerialFromCollection(poolName: String, serial: String) {
        val doc = _currentDocument.value ?: return
        if (doc.type != DocumentType.SERIAL_COLLECTION) return
        val lines = doc.lines.mapNotNull { line ->
            val matchPool = poolName.isBlank() || line.productName.equals(poolName, ignoreCase = true)
            if (!matchPool || serial !in line.serials) return@mapNotNull line
            val newSerials = line.serials.filter { it != serial }
            if (newSerials.isEmpty()) null
            else line.copy(serials = newSerials, quantity = BigDecimal(newSerials.size))
        }
        val updated = doc.copy(lines = lines)
        _currentDocument.value = updated
        _uiState.value = UiState.Document(updated)
        viewModelScope.launch { repository.saveDocument(updated) }
    }


    fun deleteDocument(id: String) {
        viewModelScope.launch {
            repository.deleteDocument(id)
            refreshList()
        }
    }

    fun saveCurrent() {
        val doc = _currentDocument.value ?: return
        viewModelScope.launch {
            repository.saveDocument(doc)
            try {
                if (doc.type == DocumentType.SERIAL_COLLECTION) {
                    val path = withContext(Dispatchers.IO) { exportSerialsToTxt(doc) }
                    _message.value = "Сохранено, TXT: $path"
                } else {
                    val msg = withContext(Dispatchers.IO) { syncManager.exportDocuments(listOf(doc)) }
                    _message.value = msg  // «Выгрузка прошла успешно» / ошибка
                }
            } catch (e: Exception) {
                _message.value = "Ошибка: сохранено локально — ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }


    /** Выгрузить все документы (кроме уже отправленных можно повторить). */
    fun exportAllDocuments() {
        viewModelScope.launch {
            val docs = _documents.value
            if (docs.isEmpty()) {
                _message.value = "Нет документов для выгрузки"
                return@launch
            }
            var ok = 0
            var fail = 0
            val errors = mutableListOf<String>()
            for (doc in docs) {
                try {
                    if (doc.type == DocumentType.SERIAL_COLLECTION) {
                        withContext(Dispatchers.IO) { exportSerialsToTxt(doc) }
                    } else {
                        withContext(Dispatchers.IO) { syncManager.exportDocuments(listOf(doc)) }
                        repository.markSent(doc.id)
                    }
                    ok++
                } catch (e: Exception) {
                    fail++
                    errors.add("${doc.number}: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            refreshList()
            _message.value = if (fail == 0) {
                AppLog.simple("Выгрузка всех документов: OK")

                "Выгружено документов: $ok"
            } else {
                "Ошибка: выгружено $ok, ошибок $fail. " + errors.take(3).joinToString("; ")
            }
        }
    }

    fun exportCurrent() {
        val doc = _currentDocument.value ?: return
        viewModelScope.launch {
            try {
                if (doc.type == DocumentType.SERIAL_COLLECTION) {
                    val path = withContext(Dispatchers.IO) { exportSerialsToTxt(doc) }
                    _message.value = "TXT: $path"
                } else {
                    val msg = withContext(Dispatchers.IO) { syncManager.exportDocuments(listOf(doc)) }
                    repository.markSent(doc.id)
                    _message.value = msg
                    refreshList()
                }
            } catch (e: Exception) {
                _message.value = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    private fun exportSerialsToTxt(doc: Document): String {
        // Содержимое: «# ИмяПула» + номера; несколько пулов в одном файле
        val content = buildString {
            val lines = doc.lines.filter { it.serials.isNotEmpty() }
            if (lines.isEmpty()) {
                appendLine("# empty")
            } else {
                for (line in lines) {
                    val pool = line.productName.trim().ifBlank { "default" }
                    appendLine("# $pool")
                    for (s in line.serials) appendLine(s)
                    appendLine()
                }
            }
        }
        val raw = "serials_${doc.number}"
        val file = syncManager.exportSerialsTxtContent(content, raw)
        return file.absolutePath
    }

    fun updateSerialPoolName(name: String) {
        _activePoolName.value = name.trim()
    }


    fun importNomenclature() {
        viewModelScope.launch {
            try {
                // номенклатура + documents_* с FTP, удаление принятых documents_* на сервере
                val msg = withContext(Dispatchers.IO) { syncManager.pullFromServer() }
                _message.value = msg
                refreshProductCount()
                loadProducts()
                refreshList()
                refreshCatalogs()
            } catch (e: Exception) {
                _message.value = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    /** Только подтянуть задания/документы с 1С (FTP to_tsd). */
    fun pullDocumentsFrom1C() {
        viewModelScope.launch {
            try {
                val msg = withContext(Dispatchers.IO) { syncManager.pullFromServer() }
                _message.value = msg
                refreshList()
                refreshProductCount()
            } catch (e: Exception) {
                _message.value = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun clearMessage() { _message.value = null }
    fun clearLastExternal() {
        _lastSerial.value = null
        _lastMark.value = null
    }

    fun ensureExchangeFolder(): String {
        val path = syncManager.exportDir().absolutePath
        _message.value = "Папка обмена:\n$path"
        return path
    }

    private var cachedExchangePath: String? = null
    fun exchangeFolderPath(): String {
        cachedExchangePath?.let { return it }
        return try {
            syncManager.exchangeDirPath().also { cachedExchangePath = it }
        } catch (e: Exception) {
            e.message ?: ""
        }
    }


    fun ftpTest() {
        viewModelScope.launch {
            try {
                val msg = withContext(Dispatchers.IO) { syncManager.ftpTest() }
                _message.value = msg
            } catch (e: Exception) {
                _message.value = "Ошибка: FTP — ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun ftpPull() {
        viewModelScope.launch {
            try {
                val msg = withContext(kotlinx.coroutines.Dispatchers.IO) { syncManager.ftpPullIncoming() }
                _message.value = msg
            } catch (e: Exception) {
                _message.value = "Ошибка: FTP — ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun ftpPush() {
        viewModelScope.launch {
            try {
                val msg = withContext(kotlinx.coroutines.Dispatchers.IO) { syncManager.ftpPushExports() }
                _message.value = msg
            } catch (e: Exception) {
                _message.value = "Ошибка: FTP — ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun exportLogs(context: android.content.Context) {
        viewModelScope.launch {
            try {
                val path = withContext(Dispatchers.IO) {
                    AppLog.exportLogs(context.applicationContext)
                }
                _message.value = "Логи сохранены"
                AppLog.simple("Логи выгружены")
            } catch (e: Exception) {
                _message.value = "Ошибка выгрузки логов"
            }
        }
    }

}

