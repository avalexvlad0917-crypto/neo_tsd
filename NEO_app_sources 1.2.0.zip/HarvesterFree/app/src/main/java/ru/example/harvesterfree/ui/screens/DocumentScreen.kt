package ru.example.harvesterfree.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.example.harvesterfree.data.SettingsRepository
import ru.example.harvesterfree.data.model.Document
import ru.example.harvesterfree.data.model.DocumentColumn
import ru.example.harvesterfree.data.model.DocumentLine
import ru.example.harvesterfree.data.model.DocumentType
import ru.example.harvesterfree.data.model.Organization
import ru.example.harvesterfree.data.model.Warehouse

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScreen(
    document: Document,
    settings: SettingsRepository,
    organizations: List<Organization> = emptyList(),
    warehouses: List<Warehouse> = emptyList(),
    onBack: () -> Unit,
    onScanClick: () -> Unit,
    onDeleteLine: (String) -> Unit,
    onDeleteSerial: (poolName: String, serial: String) -> Unit = { _, _ -> },
    onPoolNameChange: (String) -> Unit = {},
    onOrganizationChange: (id: String?, name: String?) -> Unit = { _, _ -> },
    onWarehouseChange: (id: String?, name: String?) -> Unit = { _, _ -> },
    activeLineIdForSerials: String? = null,
    onSelectLineForSerials: (String?) -> Unit = {},
    onSave: () -> Unit,
    onExport: () -> Unit
) {
    val isSerialDoc = document.type == DocumentType.SERIAL_COLLECTION
    val visible = settings.visibleColumns

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(document.number, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = document.type.toRussian(),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    TextButton(onClick = onExport) {
                        Text(
                            "Выгрузить",
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onSave) {
                        Icon(Icons.Default.Save, contentDescription = "Сохранить")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onScanClick) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "Сканировать")
            }
        }
    ) { padding ->
        if (isSerialDoc) {
            SerialCollectionContent(
                document = document,
                modifier = Modifier.padding(padding),
                onDeleteSerial = onDeleteSerial,
                onPoolNameChange = onPoolNameChange
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                DocumentOrgWarehouseBar(
                    document = document,
                    organizations = organizations,
                    warehouses = warehouses,
                    onOrganizationChange = onOrganizationChange,
                    onWarehouseChange = onWarehouseChange
                )
                if (document.lines.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Нажмите кнопку сканирования,\nчтобы добавить товар",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(start = 0.dp, top = 12.dp, end = 0.dp, bottom = 88.dp)
                    ) {
                        items(document.lines, key = { it.id }) { line ->
                            LineCard(
                                line = line,
                                visible = visible,
                                selectedForSerials = activeLineIdForSerials == line.id,
                                onSelectForSerials = {
                                    if (activeLineIdForSerials == line.id) onSelectLineForSerials(null)
                                    else onSelectLineForSerials(line.id)
                                },
                                onDelete = { onDeleteLine(line.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DocumentOrgWarehouseBar(
    document: Document,
    organizations: List<Organization>,
    warehouses: List<Warehouse>,
    onOrganizationChange: (String?, String?) -> Unit,
    onWarehouseChange: (String?, String?) -> Unit
) {
    var orgExpanded by remember { mutableStateOf(false) }
    var whExpanded by remember { mutableStateOf(false) }
    val orgLabel = document.organizationName?.takeIf { it.isNotBlank() } ?: "— не выбрана —"
    val whLabel = document.warehouseName?.takeIf { it.isNotBlank() } ?: "— не выбран —"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text("Организация", style = MaterialTheme.typography.labelMedium)
        ExposedDropdownMenuBox(
            expanded = orgExpanded,
            onExpandedChange = { orgExpanded = it }
        ) {
            OutlinedTextField(
                value = orgLabel,
                onValueChange = {},
                readOnly = true,
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = orgExpanded) },
                singleLine = true
            )
            ExposedDropdownMenu(
                expanded = orgExpanded,
                onDismissRequest = { orgExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("— не выбрана —") },
                    onClick = {
                        onOrganizationChange(null, null)
                        orgExpanded = false
                    }
                )
                organizations.forEach { o ->
                    DropdownMenuItem(
                        text = { Text(o.name) },
                        onClick = {
                            onOrganizationChange(o.id, o.name)
                            orgExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Склад", style = MaterialTheme.typography.labelMedium)
        ExposedDropdownMenuBox(
            expanded = whExpanded,
            onExpandedChange = { whExpanded = it }
        ) {
            OutlinedTextField(
                value = whLabel,
                onValueChange = {},
                readOnly = true,
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = whExpanded) },
                singleLine = true
            )
            ExposedDropdownMenu(
                expanded = whExpanded,
                onDismissRequest = { whExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("— не выбран —") },
                    onClick = {
                        onWarehouseChange(null, null)
                        whExpanded = false
                    }
                )
                warehouses.forEach { w ->
                    DropdownMenuItem(
                        text = { Text(w.name) },
                        onClick = {
                            onWarehouseChange(w.id, w.name)
                            whExpanded = false
                        }
                    )
                }
            }
        }
        if (organizations.isEmpty() && warehouses.isEmpty()) {
            Text(
                "Справочники пусты. Загрузите их с 1С в настройках.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SerialCollectionContent(
    document: Document,
    modifier: Modifier = Modifier,
    onDeleteSerial: (poolName: String, serial: String) -> Unit = { _, _ -> },
    onPoolNameChange: (String) -> Unit = {}
) {
    val pools = document.lines
    var poolName by remember(document.id) {
        mutableStateOf(
            document.lines.lastOrNull()?.productName?.takeIf { it.isNotBlank() } ?: ""
        )
    }
    val totalSerials = pools.sumOf { it.serials.size }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        OutlinedTextField(
            value = poolName,
            onValueChange = {
                poolName = it
                onPoolNameChange(it)
            },
            label = { Text("Текущий пул серийных номеров") },
            placeholder = { Text("Например: Партия-A") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            supportingText = {
                Text("Сканы попадают в этот пул. Смените имя — начнёте другой пул в том же документе.")
            }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = MaterialTheme.shapes.medium
        ) {
            Text(
                text = "Считано серийных номеров: $totalSerials\nПулов: ${pools.size}",
                modifier = Modifier.padding(12.dp),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "При выгрузке в TXT перед каждым пулом пишется строка «# ИмяПула», затем номера.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (pools.isEmpty() || totalSerials == 0) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Список пуст — укажите пул и сканируйте номера")
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                pools.forEach { line ->
                    val name = line.productName.ifBlank { "без имени" }
                    item(key = "hdr-${line.id}") {
                        Text(
                            text = "Пул: $name (${line.serials.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(
                        items = line.serials,
                        key = { s -> "${line.id}-$s" }
                    ) { s ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = s,
                                    modifier = Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                IconButton(onClick = { onDeleteSerial(line.productName, s) }) {
                                    Icon(Icons.Default.Delete, contentDescription = null)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LineCard(
    line: DocumentLine,
    visible: Set<DocumentColumn>,
    selectedForSerials: Boolean = false,
    onSelectForSerials: () -> Unit = {},
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = if (selectedForSerials) {
            CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        } else {
            CardDefaults.cardColors()
        }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectForSerials() }
                ) {
                    if (DocumentColumn.NAME in visible) {
                        Text(line.productName, fontWeight = FontWeight.SemiBold)
                    }
                    if (DocumentColumn.BARCODE in visible) {
                        Text(
                            line.barcode,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (DocumentColumn.QUANTITY in visible) {
                            Text("Кол-во: ${line.quantity}")
                        }
                        if (DocumentColumn.UNIT in visible) {
                            Text(line.unit)
                        }
                        if (DocumentColumn.PRICE in visible) {
                            Text("Цена: ${line.price}")
                        }
                        if (DocumentColumn.AMOUNT in visible) {
                            Text("Сумма: ${line.amount}")
                        }
                    }
                    Text(
                        "Серии: ${line.serials.size}" +
                            if (line.serials.isNotEmpty()) " — ${line.serials.joinToString()}" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (selectedForSerials) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (selectedForSerials) {
                        Text(
                            "▶ Режим серий: сканируйте заводские номера (кол-во = число серий)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Text(
                            "Нажмите на строку → ввод заводских номеров",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (DocumentColumn.MARKS in visible && line.marks.isNotEmpty()) {
                        Text(
                            "КМ: ${line.marks.size}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                }
            }
        }
    }
}

fun DocumentType.toRussian(): String = when (this) {
    DocumentType.RECEIPT -> "Приёмка"
    DocumentType.SHIPMENT -> "Отгрузка"
    DocumentType.INVENTORY -> "Инвентаризация"
    DocumentType.WRITE_OFF -> "Списание"
    DocumentType.MOVEMENT -> "Перемещение"
    DocumentType.CUSTOMER_ORDER -> "Заказ клиента"
    DocumentType.SERIAL_COLLECTION -> "Сбор серийных номеров"
    DocumentType.GOODS_RECEIPT_ORDER -> "Приходный ордер на товары"
    DocumentType.GOODS_ISSUE_ORDER -> "Расходный ордер на товары"
    DocumentType.MOVEMENT_ORDER -> "Ордер на перемещение"
    DocumentType.SURPLUS_ORDER -> "Ордер на отражение излишков"
    DocumentType.SHORTAGE_ORDER -> "Ордер на отражение недостач"
    DocumentType.DAMAGE_ORDER -> "Ордер на отражение порчи"
    DocumentType.PURCHASE_ORDER -> "Заказ поставщику"
    DocumentType.MOVEMENT_REQUEST -> "Заказ на перемещение"
}
