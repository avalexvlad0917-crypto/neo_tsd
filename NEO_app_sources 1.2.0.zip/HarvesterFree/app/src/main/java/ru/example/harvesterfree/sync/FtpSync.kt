package ru.example.harvesterfree.sync

import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import org.apache.commons.net.ftp.FTPReply
import ru.example.harvesterfree.data.SettingsRepository
import ru.example.harvesterfree.util.AppLog
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/**
 * FTP-клиент. Один сеанс = одно TCP-соединение.
 * После connect() текущий каталог = корень обмена (ftpRemotePath или home).
 */
class FtpSync(private val settings: SettingsRepository) {

    fun isConfigured(): Boolean =
        settings.ftpHost.isNotBlank() && settings.ftpUser.isNotBlank()

    private fun errMsg(e: Throwable): String {
        val m = e.message?.trim().orEmpty()
        if (m.isNotEmpty() && m != "null") return m
        return e.javaClass.simpleName + (e.cause?.let { " / ${errMsg(it)}" } ?: "")
    }

    /** Нормализация пути: обратные слэши → прямые, обрезка краёв. */
    private fun normalizePath(raw: String): String {
        val bs = 92.toChar() // backslash
        return raw.map { ch -> if (ch == bs) '/' else ch }.joinToString("")
            .trim('/')
    }

    private fun splitRemotePath(remoteRelative: String): Pair<String, String> {
        val path = normalizePath(remoteRelative)
        val slash = path.lastIndexOf('/')
        return if (slash >= 0) {
            path.substring(0, slash) to path.substring(slash + 1)
        } else {
            "" to path
        }
    }

    private fun newClient(): FTPClient {
        val client = FTPClient()
        client.connectTimeout = 15_000
        client.defaultTimeout = 30_000
        client.setDataTimeout(30_000)
        client.setBufferSize(128 * 1024)
        return client
    }

    private fun connect(): FTPClient {
        if (!isConfigured()) throw IllegalStateException("FTP не настроен (хост/логин)")
        val host = settings.ftpHost.trim()
        val port = settings.ftpPort
        var last: Exception? = null
        for (attempt in 1..3) {
            val client = newClient()
            try {
                client.connect(host, port)
                if (!FTPReply.isPositiveCompletion(client.replyCode)) {
                    val reply = "${client.replyCode} ${client.replyString}"
                    client.disconnect()
                    throw IOException("Нет приветствия FTP: $reply")
                }
                if (!client.login(settings.ftpUser, settings.ftpPassword)) {
                    val reply = client.replyString
                    client.disconnect()
                    throw IOException("Логин отклонён: $reply")
                }
                client.setFileType(FTP.BINARY_FILE_TYPE)
                client.setFileTransferMode(FTP.STREAM_TRANSFER_MODE)
                runCatching { client.setControlEncoding("UTF-8") }
                if (settings.ftpPassive) client.enterLocalPassiveMode()
                else client.enterLocalActiveMode()
                goToExchangeRoot(client)
                AppLog.i("FtpSync", "connected $host:$port pwd=${client.printWorkingDirectory()}")
                return client
            } catch (e: Exception) {
                last = e
                disconnectQuietly(client)
                AppLog.w("FtpSync", "connect #$attempt: ${errMsg(e)}")
                if (attempt < 3) {
                    try {
                        Thread.sleep(500L * attempt)
                    } catch (_: InterruptedException) {
                    }
                }
            }
        }
        throw IOException(
            "Нет связи $host:$port — ${last?.let { errMsg(it) } ?: "unknown"}",
            last
        )
    }

    private fun goToExchangeRoot(client: FTPClient) {
        val remote = settings.ftpRemotePath.trim().trimEnd('/')
        if (remote.isEmpty()) return
        val pwd = client.printWorkingDirectory()?.trimEnd('/') ?: ""
        if (pwd.equals(remote, true) || pwd.equals("/${remote.trimStart('/')}", true)) return

        val candidates = listOf(remote, remote.trimStart('/'), "/${remote.trimStart('/')}")
            .distinct()
        for (path in candidates) {
            if (client.changeWorkingDirectory(path)) {
                AppLog.i("FtpSync", "CWD $path")
                return
            }
        }
        AppLog.w(
            "FtpSync",
            "удалённый путь «$remote» недоступен (${client.replyString}), работаем из ${client.printWorkingDirectory()}"
        )
    }

    private fun disconnectQuietly(client: FTPClient?) {
        if (client == null) return
        runCatching {
            if (client.isConnected) {
                runCatching { client.logout() }
                client.disconnect()
            }
        }
    }

    private fun ensureSubDir(client: FTPClient, name: String) {
        val cur = client.printWorkingDirectory()
        if (client.changeWorkingDirectory(name)) {
            restoreDir(client, cur)
            return
        }
        client.makeDirectory(name)
        if (client.changeWorkingDirectory(name)) {
            restoreDir(client, cur)
            return
        }
        AppLog.w("FtpSync", "ensureSubDir $name: ${client.replyString}")
    }

    private fun restoreDir(client: FTPClient, cur: String?) {
        if (cur != null) {
            if (!client.changeWorkingDirectory(cur)) goToExchangeRoot(client)
        } else goToExchangeRoot(client)
    }

    private fun listInCurrent(client: FTPClient): List<FTPFile> {
        if (settings.ftpPassive) client.enterLocalPassiveMode()
        val files = client.listFiles()
            ?: throw IOException("LIST не удался: ${client.replyString}. Проверьте пассивные порты FileZilla.")
        return files.filter { it.name != "." && it.name != ".." }
    }

    fun testConnection(): String {
        val client = connect()
        try {
            // Проверка: connect + LIST корня обмена
            listInCurrent(client)
            return "Подключение FTP OK"
        } finally {
            disconnectQuietly(client)
        }
    }

    fun downloadIncoming(localDir: File): String {
        if (!isConfigured()) throw IllegalStateException("FTP не настроен")
        localDir.mkdirs()
        val client = connect()
        val log = StringBuilder()
        try {
            ensureSubDir(client, "to_tsd")
            ensureSubDir(client, "from_tsd")

            var downloaded = 0

            fun tryDownloadFromCurrent(folderLabel: String) {
                val files = listInCurrent(client)
                for (f in files) {
                    if (!f.isFile) continue
                    val name = f.name
                    val lower = name.lowercase()
                    val isNom = lower == "nomenclature.json" ||
                        lower == "nomenclaturejson" ||
                        (lower.contains("nomenclature") && lower.endsWith("json"))
                    val isDoc = lower.startsWith("documents_") && lower.endsWith(".json")
                    val isCat = lower == "catalogs.json" || lower == "catalogsjson" ||
                        (lower.contains("catalog") && lower.endsWith("json"))
                    if (!isNom && !isDoc && !isCat) continue
                    val localName = when {
                        isNom -> "nomenclature.json"
                        isCat -> "catalogs.json"
                        else -> name
                    }
                    val local = File(localDir, localName)
                    if (settings.ftpPassive) client.enterLocalPassiveMode()
                    FileOutputStream(local).use { out ->
                        if (!client.retrieveFile(name, out)) {
                            throw IOException("RETR $folderLabel/$name: ${client.replyString}")
                        }
                    }
                    downloaded++
                    log.append("↓ $folderLabel/$name; ")
                    AppLog.i("FtpSync", "download $folderLabel/$name → ${local.absolutePath}")
                }
            }

            val root = client.printWorkingDirectory()
            var gotNomenclature = false

            if (client.changeWorkingDirectory("to_tsd")) {
                tryDownloadFromCurrent("to_tsd")
                if (File(localDir, "nomenclature.json").exists()) gotNomenclature = true
                restoreDir(client, root)
            }

            if (!gotNomenclature) {
                goToExchangeRoot(client)
                tryDownloadFromCurrent("root")
            } else {
                AppLog.i("FtpSync", "nomenclature из to_tsd — корень пропускаем")
            }

            if (downloaded == 0) {
                goToExchangeRoot(client)
                val listing = listInCurrent(client).joinToString(", ") {
                    if (it.isDirectory) "[${it.name}]" else it.name
                }
                AppLog.w("FtpSync", "нечего скачивать: $listing")
                return "На FTP нет nomenclature/documents_*. Сейчас: $listing"
            }
            return "Скачано: $downloaded. $log"
        } finally {
            disconnectQuietly(client)
        }
    }

    fun uploadFile(local: File, remoteRelative: String) {
        if (!isConfigured()) throw IllegalStateException("FTP не настроен")
        if (!local.exists()) throw IllegalStateException("Нет файла: ${local.absolutePath}")
        val client = connect()
        try {
            val (dir, name) = splitRemotePath(remoteRelative)
            goToExchangeRoot(client)
            if (dir.isNotEmpty()) {
                for (part in dir.split('/').filter { it.isNotEmpty() }) {
                    if (!client.changeWorkingDirectory(part)) {
                        client.makeDirectory(part)
                        if (!client.changeWorkingDirectory(part)) {
                            throw IOException("Не создать $part: ${client.replyString}")
                        }
                    }
                }
            }
            if (settings.ftpPassive) client.enterLocalPassiveMode()
            FileInputStream(local).use { input ->
                if (!client.storeFile(name, input)) {
                    throw IOException("STOR $name: ${client.replyString}")
                }
            }
            AppLog.i("FtpSync", "upload ${local.name} → $remoteRelative")
        } finally {
            disconnectQuietly(client)
        }
    }

    fun uploadExports(localDir: File) {
        localDir.listFiles { f ->
            f.isFile && (
                f.name.startsWith("export_", true) ||
                    f.name.startsWith("serials_", true) ||
                    f.name.endsWith(".txt", true)
                )
        }?.forEach { f ->
            val remote = if (f.name.startsWith("export_", true)) {
                "from_tsd/${f.name}"
            } else {
                f.name
            }
            uploadFile(f, remote)
        }
    }

    /** Удалить файл на FTP относительно корня обмена, например to_tsd/documents_x.json */
    fun deleteRemote(remoteRelative: String) {
        if (!isConfigured()) return
        val client = connect()
        try {
            val (dir, name) = splitRemotePath(remoteRelative)
            if (name.isEmpty()) return
            goToExchangeRoot(client)
            if (dir.isNotEmpty()) {
                for (part in dir.split('/').filter { it.isNotEmpty() }) {
                    if (!client.changeWorkingDirectory(part)) {
                        AppLog.w("FtpSync", "delete: нет каталога $part")
                        return
                    }
                }
            }
            if (!client.deleteFile(name)) {
                AppLog.w("FtpSync", "delete $dir/$name: ${client.replyString}")
            } else {
                AppLog.i("FtpSync", "deleted remote $dir/$name")
            }
        } finally {
            disconnectQuietly(client)
        }
    }
}
