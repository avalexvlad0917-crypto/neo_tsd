package ru.example.harvesterfree.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.example.harvesterfree.data.model.Product

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NomenclatureScreen(
    products: List<Product>,
    onSearch: (String) -> Unit,
    onSave: (Product) -> Unit,
    onDelete: (String) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Product?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Номенклатура (${products.size})") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, null)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    onSearch(it)
                },
                label = { Text("Поиск") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(products, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f).clickable { editing = p }) {
                                Text(p.name, style = MaterialTheme.typography.titleSmall)
                                Text("ШК: ${p.barcode}", style = MaterialTheme.typography.bodySmall)
                                Text(
                                    "Цена: ${p.price ?: 0.0}  ·  ${p.unit}" +
                                        (p.article?.let { "  ·  $it" } ?: ""),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { editing = p }) {
                                Icon(Icons.Default.Edit, null)
                            }
                            IconButton(onClick = { onDelete(p.id) }) {
                                Icon(Icons.Default.Delete, null)
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { product ->
        EditProductDialog(
            product = product,
            onDismiss = { editing = null },
            onSave = {
                onSave(it)
                editing = null
            }
        )
    }
}

@Composable
private fun EditProductDialog(
    product: Product,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var name by remember { mutableStateOf(product.name) }
    var barcode by remember { mutableStateOf(product.barcode) }
    var unit by remember { mutableStateOf(product.unit) }
    var article by remember { mutableStateOf(product.article ?: "") }
    var price by remember { mutableStateOf((product.price ?: 0.0).toString()) }
    var hasSerials by remember { mutableStateOf(product.hasSerials) }
    var isMarked by remember { mutableStateOf(product.isMarked) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактирование") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Наименование") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(barcode, { barcode = it }, label = { Text("Штрихкод") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(unit, { unit = it }, label = { Text("Ед.") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(article, { article = it }, label = { Text("Артикул") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(price, { price = it }, label = { Text("Цена (стоимость)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(hasSerials, { hasSerials = it })
                    Text("Учёт по сериям")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(isMarked, { isMarked = it })
                    Text("Маркировка")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    product.copy(
                        name = name.trim().ifBlank { product.name },
                        barcode = barcode.trim().ifBlank { product.barcode },
                        unit = unit.trim().ifBlank { "шт" },
                        article = article.trim().ifBlank { null },
                        price = price.replace(',', '.').toDoubleOrNull() ?: 0.0,
                        hasSerials = hasSerials,
                        isMarked = isMarked
                    )
                )
            }) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
