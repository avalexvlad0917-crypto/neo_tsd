package ru.example.harvesterfree.data.repository

import com.google.gson.Gson
import ru.example.harvesterfree.data.local.AppDatabase
import ru.example.harvesterfree.data.model.*
import java.math.BigDecimal
import java.math.RoundingMode

class DocumentRepository(private val db: AppDatabase) {

    private val gson = Gson()
    private val productDao = db.productDao()
    private val documentDao = db.documentDao()

    suspend fun findProduct(barcode: String): Product? {
        productDao.findByBarcode(barcode)?.let { return it }
        val gtin = if (barcode.length == 13) "0$barcode" else barcode
        return productDao.findByGtin(gtin)
    }

    suspend fun findProductByGtin(gtin: String): Product? = productDao.findByGtin(gtin)

    suspend fun getAllProducts(): List<Product> = productDao.getAll()

    suspend fun searchProducts(q: String): List<Product> =
        if (q.isBlank()) productDao.getAll() else productDao.search(q)

    suspend fun saveProduct(product: Product) = productDao.insert(product)

    suspend fun deleteProduct(id: String) = productDao.deleteById(id)

    suspend fun replaceAllProducts(products: List<Product>) {
        productDao.clear()
        productDao.insertAll(products)
    }

    suspend fun productCount(): Int = productDao.count()

    suspend fun getAllDocuments(): List<Document> {
        return documentDao.getAllWithLines().map { it.toDomain() }
    }

    suspend fun getDocument(id: String): Document? {
        return documentDao.getById(id)?.toDomain()
    }

    suspend fun saveDocument(doc: Document) {
        val entity = DocumentEntity(
            id = doc.id,
            type = doc.type,
            number = doc.number,
            date = doc.date,
            status = doc.status,
            comment = doc.comment,
            organizationId = doc.organizationId,
            organizationName = doc.organizationName,
            warehouseId = doc.warehouseId,
            warehouseName = doc.warehouseName
        )
        documentDao.insertDocument(entity)
        documentDao.deleteLines(doc.id)
        val lines = doc.lines.map { line ->
            val qty = line.quantity.toDouble()
            val price = line.price.toDouble()
            val amount = if (line.amount != BigDecimal.ZERO) line.amount.toDouble()
            else qty * price
            DocumentLineEntity(
                id = line.id,
                documentId = doc.id,
                productId = line.productId,
                barcode = line.barcode,
                productName = line.productName,
                quantity = qty,
                unit = line.unit,
                price = price,
                amount = amount,
                serialsJson = gson.toJson(line.serials),
                marksJson = gson.toJson(line.marks)
            )
        }
        documentDao.insertLines(lines)
    }

    suspend fun deleteDocument(id: String) {
        documentDao.deleteDocument(id)
    }

    suspend fun markSent(id: String) {
        documentDao.updateStatus(id, DocumentStatus.SENT)
    }

    private fun DocumentWithLines.toDomain(): Document {
        return Document(
            id = document.id,
            type = document.type,
            number = document.number,
            date = document.date,
            status = document.status,
            comment = document.comment,
            organizationId = document.organizationId,
            organizationName = document.organizationName,
            warehouseId = document.warehouseId,
            warehouseName = document.warehouseName,
            lines = lines.map { line ->
                DocumentLine(
                    id = line.id,
                    barcode = line.barcode,
                    productName = line.productName,
                    quantity = BigDecimal.valueOf(line.quantity),
                    unit = line.unit,
                    price = BigDecimal.valueOf(line.price).setScale(2, RoundingMode.HALF_UP),
                    amount = BigDecimal.valueOf(line.amount).setScale(2, RoundingMode.HALF_UP),
                    serials = gson.fromJson(line.serialsJson, Array<String>::class.java)?.toList() ?: emptyList(),
                    marks = gson.fromJson(line.marksJson, Array<String>::class.java)?.toList() ?: emptyList(),
                    productId = line.productId
                )
            }
        )
    }

    private val catalogDao = db.catalogDao()

    suspend fun getOrganizations(): List<Organization> = catalogDao.getOrganizations()
    suspend fun getWarehouses(): List<Warehouse> = catalogDao.getWarehouses()

    suspend fun saveOrganizations(items: List<Organization>) {
        catalogDao.clearOrganizations()
        if (items.isNotEmpty()) catalogDao.insertOrganizations(items)
    }

    suspend fun saveWarehouses(items: List<Warehouse>) {
        catalogDao.clearWarehouses()
        if (items.isNotEmpty()) catalogDao.insertWarehouses(items)
    }

    suspend fun catalogCounts(): Pair<Int, Int> =
        catalogDao.countOrganizations() to catalogDao.countWarehouses()
}
