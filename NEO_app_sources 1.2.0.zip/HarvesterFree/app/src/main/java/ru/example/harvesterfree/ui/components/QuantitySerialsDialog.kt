package ru.example.harvesterfree.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import java.math.BigDecimal

/**
 * Диалог после сканирования ШК.
 * Серийные (заводские) номера вводятся строго по количеству (целое число).
 */
@Composable
fun QuantitySerialsDialog(
    productName: String,
    barcode: String,
    isMarked: Boolean = false,
    enableFactorySerial: Boolean = true,
    initialQuantity: String = "1",
    externalSerial: String? = null,
    externalMark: String? = null,
    onExternalConsumed: () -> Unit = {},
    onConfirm: (quantity: BigDecimal, serials: List<String>, marks: List<String>) -> Unit,
    onDismiss: () -> Unit,
    onScanSerialOrMark: () -> Unit
) {
    var quantityText by remember { mutableStateOf(initialQuantity) }
    var serials by remember { mutableStateOf(listOf<String>()) }
    var marks by remember { mutableStateOf(listOf<String>()) }
    var newSerial by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val qtyInt = remember(quantityText) {
        quantityText.replace(',', '.').toDoubleOrNull()?.toInt() ?: 1
    }.coerceAtLeast(1)

    fun tryAddSerial(value: String) {
        val v = value.trim()
        if (v.isBlank()) return
        if (v in serials) {
            error = "Номер уже добавлен"
            return
        }
        if (serials.size >= qtyInt) {
            error = "Нужно ровно $qtyInt заводских номеров (по количеству)"
            return
        }
        serials = serials + v
        error = null
    }

    LaunchedEffect(externalSerial, externalMark) {
        if (enableFactorySerial) {
            externalSerial?.takeIf { it.isNotBlank() }?.let {
                tryAddSerial(it)
                onExternalConsumed()
            }
        }
        externalMark?.takeIf { it.isNotBlank() }?.let {
            if (it !in marks) marks = marks + it.trim()
            onExternalConsumed()
        }
    }

    // Если уменьшили количество — обрезаем лишние серии
    LaunchedEffect(qtyInt) {
        if (serials.size > qtyInt) {
            serials = serials.take(qtyInt)
        }
    }

    val serialsOk = !enableFactorySerial || serials.size == qtyInt
    val marksOk = !isMarked || marks.size >= 1 // минимум 1 КМ если маркировка; можно ослабить

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = MaterialTheme.shapes.large
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(productName, style = MaterialTheme.typography.titleMedium)
                Text(
                    "ШК: $barcode",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (isMarked) {
                    Text(
                        "Маркированный товар",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelMedium
                    )
                }

                OutlinedTextField(
                    value = quantityText,
                    onValueChange = {
                        quantityText = it.filter { c -> c.isDigit() || c == '.' || c == ',' }
                        error = null
                    },
                    label = { Text("Количество") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = if (enableFactorySerial) {
                        { Text("Для серий используется целое количество: $qtyInt") }
                    } else null
                )

                if (enableFactorySerial) {
                    HorizontalDivider()
                    Text(
                        "Заводские номера: ${serials.size} / $qtyInt",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (serialsOk) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )

                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 120.dp)) {
                        itemsIndexed(serials) { index, s ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${index + 1}. $s", modifier = Modifier.weight(1f))
                                IconButton(onClick = {
                                    serials = serials.toMutableList().also { it.removeAt(index) }
                                }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                    }

                    if (serials.size < qtyInt) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = newSerial,
                                onValueChange = { newSerial = it },
                                label = { Text("Заводской № ${serials.size + 1} из $qtyInt") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                tryAddSerial(newSerial)
                                newSerial = ""
                            }) { Icon(Icons.Default.Add, null) }
                        }

                        Button(
                            onClick = onScanSerialOrMark,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Сканировать заводской номер (${serials.size + 1}/$qtyInt)")
                        }
                    }
                }

                if (isMarked || marks.isNotEmpty()) {
                    if (!enableFactorySerial) HorizontalDivider()
                    Text("Коды маркировки (КМ): ${marks.size}", style = MaterialTheme.typography.titleSmall)
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 80.dp)) {
                        itemsIndexed(marks) { index, m ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "${index + 1}. ${m.take(28)}${if (m.length > 28) "…" else ""}",
                                    modifier = Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodySmall
                                )
                                IconButton(onClick = {
                                    marks = marks.toMutableList().also { it.removeAt(index) }
                                }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                    }
                    Button(onClick = onScanSerialOrMark, modifier = Modifier.fillMaxWidth()) {
                        Text("Сканировать КМ")
                    }
                }

                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Отмена") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = serialsOk,
                        onClick = {
                            if (!serialsOk) {
                                error = "Введите $qtyInt заводских номеров"
                                return@Button
                            }
                            val qty = quantityText.replace(',', '.').toBigDecimalOrNull()
                                ?: BigDecimal.valueOf(qtyInt.toLong())
                            onConfirm(qty, if (enableFactorySerial) serials else emptyList(), marks)
                        }
                    ) {
                        Text("Добавить")
                    }
                }
            }
        }
    }
}
