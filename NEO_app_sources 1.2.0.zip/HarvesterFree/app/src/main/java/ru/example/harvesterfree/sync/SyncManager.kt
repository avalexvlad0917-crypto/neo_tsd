package ru.example.harvesterfree.sync

import android.content.Context
import android.os.Environment
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import ru.example.harvesterfree.data.SettingsRepository
import ru.example.harvesterfree.data.model.Document
import ru.example.harvesterfree.data.repository.DocumentRepository
import ru.example.harvesterfree.util.AppLog
import java.io.File
import java.util.concurrent.TimeUnit

class SyncManager(
    private val context: Context,
    private val repository: DocumentRepository,
    private val settings: SettingsRepository
) {
    private val ftpSync = FtpSync(settings)

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Корень пользовательской памяти: /storage/emulated/0/NEO
     * (в проводниках это «внутренняя память / NEO»).
     * /storage/NEO — пробуем, но без root часто недоступен.
     */
    fun exportDir(): File {
        val candidates = listOf(
            File(Environment.getExternalStorageDirectory(), "NEO"),
            File("/storage/emulated/0/NEO"),
            File("/sdcard/NEO"),
            File("/storage/NEO"),
            File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "NEO"),
            File(context.getExternalFilesDir(null), "NEO")
        )
        for (dir in candidates) {
            try {
                ensureDir(dir)
                if (dir.exists() && dir.canWrite()) {
                    val marker = File(dir, "readme.txt")
                    if (!marker.exists()) {
                        marker.writeText(
                            "NEO exchange folder\n" +
                                "Put nomenclature.json here\n" +
                                "export_*.json will appear here\n"
                        )
                    }
                    AppLog.i("SyncManager", "exchange dir: ${dir.absolutePath}")
                    return dir
                }
            } catch (e: Exception) {
                AppLog.w("SyncManager", "${dir.absolutePath}: ${e.message}")
            }
        }
        val fallback = File(context.filesDir, "NEO").apply { mkdirs() }
        AppLog.w("SyncManager", "fallback: ${fallback.absolutePath}")
        return fallback
    }

    private fun ensureDir(dir: File) {
        if (dir.exists()) return
        // несколько попыток
        if (dir.mkdirs()) return
        dir.parentFile?.mkdirs()
        dir.mkdirs()
        // Runtime.exec as last resort on some firmwares (no-op if blocked)
        try {
            Runtime.getRuntime().exec(arrayOf("mkdir", "-p", dir.absolutePath)).waitFor()
        } catch (_: Exception) {}
    }

    fun exchangeDir(): File = exportDir()
    fun exchangeDirPath(): String = exportDir().absolutePath


    /**
     * Скачать с FTP to_tsd → импорт nomenclature + documents_* → удалить принятые documents_* на сервере.
     */
    suspend fun pullFromServer(): String {
        val dir = exportDir()
        val ftpMsg = if (ftpSync.isConfigured()) {
            try {
                ftpSync.downloadIncoming(dir)
            } catch (e: Exception) {
                AppLog.w("SyncManager", "pull: ${e.message}")
                "FTP: ${e.message}"
            }
        } else {
            "FTP не настроен — только локальные файлы"
        }

        val parts = mutableListOf<String>()
        parts.add(ftpMsg)

        // Номенклатура
        val nomFile = File(dir, "nomenclature.json")
        if (nomFile.exists()) {
            try {
                val text = nomFile.readText()
                ExchangeMapper.extractConfigId(text)?.let {
                    settings.configId = it
                    AppLog.i("SyncManager", "configId=$it (from nomenclature)")
                }
                val n = importNomenclatureFromJson(text)
                parts.add("Номенклатура: $n")
                // удалить после успешной загрузки
                if (ftpSync.isConfigured()) {
                    runCatching { ftpSync.deleteRemote("to_tsd/nomenclature.json") }
                }
                nomFile.delete()
            } catch (e: Exception) {
                parts.add("Номенклатура: ${e.message}")
            }
        }

        // Справочники (организации, склады)
        val catFile = File(dir, "catalogs.json")
        if (catFile.exists()) {
            try {
                val text = catFile.readText()
                ExchangeMapper.extractConfigId(text)?.let {
                    settings.configId = it
                    AppLog.i("SyncManager", "configId=$it (from catalogs)")
                }
                val (orgs, whs) = ExchangeMapper.parseCatalogs(text)
                repository.saveOrganizations(orgs)
                repository.saveWarehouses(whs)
                parts.add("Справочники: орг=${orgs.size}, склады=${whs.size}")
                AppLog.i("SyncManager", "catalogs orgs=${orgs.size} whs=${whs.size}")
                if (ftpSync.isConfigured()) {
                    runCatching { ftpSync.deleteRemote("to_tsd/catalogs.json") }
                }
                catFile.delete()
            } catch (e: Exception) {
                parts.add("Справочники: ${e.message}")
            }
        }

        // Документы из 1С
        val docFiles = dir.listFiles { f ->
            f.isFile && f.name.startsWith("documents_", true) && f.name.endsWith(".json", true)
        }?.sortedBy { it.name } ?: emptyList()

        var importedDocs = 0
        for (f in docFiles) {
            try {
                val text = f.readText()
                ExchangeMapper.extractConfigId(text)?.let { settings.configId = it }
                val docs = ExchangeMapper.parseDocuments(text)
                var added = 0
                for (doc in docs) {
                    val existing = repository.getDocument(doc.id)
                    if (existing != null) {
                        AppLog.i("SyncManager", "doc ${doc.id} уже есть — пропуск")
                        continue
                    }
                    repository.saveDocument(doc)
                    added++
                    importedDocs++
                }
                parts.add("${f.name}: +$added док.")
                // удалить локально и на FTP
                val remoteName = "to_tsd/${f.name}"
                if (ftpSync.isConfigured()) {
                    runCatching { ftpSync.deleteRemote(remoteName) }
                        .onFailure { AppLog.w("SyncManager", "delete remote: ${it.message}") }
                }
                f.delete()
            } catch (e: Exception) {
                parts.add("${f.name}: ошибка ${e.message}")
                AppLog.w("SyncManager", "import ${f.name}: ${e.message}")
            }
        }
        val hasError = parts.any { it.contains("ошибка", true) || it.startsWith("FTP:") && !it.contains("OK", true) }
        val summary = buildString {
            if (hasError) append("Загрузка с ошибкой")
            else append("Загрузка прошла успешно")
            val details = mutableListOf<String>()
            if (parts.any { it.startsWith("Номенклатура:") }) details.add("номенклатура")
            if (parts.any { it.startsWith("Справочники:") }) details.add("справочники")
            if (importedDocs > 0) details.add("док.: $importedDocs")
            if (details.isNotEmpty()) append(" (" + details.joinToString(", ") + ")")
        }
        AppLog.simple(summary)
        AppLog.i("SyncManager", parts.joinToString(" | "))
        return summary
    }

    suspend fun exportDocumentsToFile(docs: List<Document>): File {
        val file = File(exportDir(), "export_${System.currentTimeMillis()}.json")
        file.writeText(ExchangeMapper.documentsToJson(docs, settings.deviceId))
        AppLog.i("SyncManager", "export ${file.absolutePath}")
        AppLog.simple("Выгрузка файла ${file.name}")
        if (ftpSync.isConfigured()) {
            try {
                ftpSync.uploadFile(file, "from_tsd/${file.name}")
            } catch (e: Exception) {
                AppLog.w("SyncManager", "FTP upload: ${e.message}")
                throw IllegalStateException("Файл записан локально, FTP ошибка: ${e.message}")
            }
        }
        return file
    }

    /** TXT серийных номеров — в корень папки обмена (+ FTP) */
    fun exportSerialsTxt(serials: List<String>, fileName: String): File {
        val dir = exportDir()
        // Только латиница/цифры/._- — кириллица в имени даёт 550 на многих FTP (FileZilla)
        val ascii = buildString {
            for (c in fileName) {
                when {
                    c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9' || c == '.' || c == '_' || c == '-' -> append(c)
                    c.isWhitespace() -> append('_')
                    else -> append('_')
                }
            }
        }.trim('_').ifEmpty { "serials_${System.currentTimeMillis()}" }
        val name = if (ascii.endsWith(".txt", ignoreCase = true)) ascii else "$ascii.txt"
        val file = File(dir, name)
        file.writeText(serials.joinToString("\n"))
        AppLog.i("SyncManager", "serials txt ${file.absolutePath}")
        if (ftpSync.isConfigured()) {
            try {
                // в from_tsd — те же права, что у export_*.json
                ftpSync.uploadFile(file, "from_tsd/$name")
            } catch (e: Exception) {
                AppLog.w("SyncManager", "FTP serials: ${e.message}")
                throw IllegalStateException("TXT локально, FTP ошибка: ${e.message}")
            }
        }
        return file
    }

    /** Выгрузка готового текста (с заголовками пулов) в TXT + FTP from_tsd */
    fun exportSerialsTxtContent(content: String, fileName: String): File {
        val dir = exportDir()
        val ascii = buildString {
            for (c in fileName) {
                when {
                    c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9' || c == '.' || c == '_' || c == '-' -> append(c)
                    c.isWhitespace() -> append('_')
                    else -> append('_')
                }
            }
        }.trim('_').ifEmpty { "serials_${System.currentTimeMillis()}" }
        val name = if (ascii.endsWith(".txt", ignoreCase = true)) ascii else "$ascii.txt"
        val file = File(dir, name)
        file.writeText(content)
        AppLog.i("SyncManager", "serials txt content ${file.absolutePath}")
        if (ftpSync.isConfigured()) {
            try {
                ftpSync.uploadFile(file, "from_tsd/$name")
            } catch (e: Exception) {
                AppLog.w("SyncManager", "FTP serials: ${e.message}")
                throw IllegalStateException("TXT локально, FTP ошибка: ${e.message}")
            }
        }
        return file
    }



    suspend fun ftpPullIncoming(): String {
        if (!ftpSync.isConfigured()) throw IllegalStateException("FTP не настроен")
        ftpSync.downloadIncoming(exportDir())
        return "FTP: файлы загружены в ${exportDir().absolutePath}"
    }

    suspend fun ftpPushExports(): String {
        if (!ftpSync.isConfigured()) throw IllegalStateException("FTP не настроен")
        ftpSync.uploadExports(exportDir())
        return "FTP: выгрузка завершена"
    }

    fun ftpTest(): String = ftpSync.testConnection()

    suspend fun exportDocumentsToHttp(docs: List<Document>): Boolean {
        val base = settings.httpBaseUrl
        if (base.isBlank()) throw IllegalStateException("Не задан URL HTTP-сервиса")
        return postJson("$base/documents", ExchangeMapper.documentsToJson(docs, settings.deviceId))
    }

    suspend fun importNomenclatureFromFile(): Int {
        val dir = exportDir()
        var ftpMsg = ""
        if (ftpSync.isConfigured()) {
            try {
                ftpMsg = ftpSync.downloadIncoming(dir)
                AppLog.i("SyncManager", ftpMsg)
            } catch (e: Exception) {
                AppLog.w("SyncManager", "FTP pull: ${e.message}")
                // если локально уже есть файл — продолжим, иначе пробросим
                val local = File(dir, "nomenclature.json")
                if (!local.exists()) {
                    throw IllegalStateException("FTP: ${e.message}")
                }
            }
        }
        val file = File(dir, "nomenclature.json")
        if (!file.exists()) {
            val candidates = dir.listFiles { f ->
                f.isFile && f.name.contains("nomenclature", true) && f.extension.equals("json", true)
            }
            if (candidates.isNullOrEmpty()) {
                throw IllegalStateException(
                    "nomenclature.json не найден локально: ${dir.absolutePath}. " +
                        "Положите файл в to_tsd или корень на FTP (D:\\neo_tsd)."
                )
            }
            return importNomenclatureFromJson(candidates.sortedByDescending { it.lastModified() }.first().readText())
        }
        return importNomenclatureFromJson(file.readText())
    }

    suspend fun importNomenclatureFromHttp(): Int {
        val base = settings.httpBaseUrl
        if (base.isBlank()) throw IllegalStateException("Не задан URL HTTP-сервиса")
        val json = getJson("$base/nomenclature") ?: throw IllegalStateException("Пустой ответ")
        return importNomenclatureFromJson(json)
    }

    private suspend fun importNomenclatureFromJson(json: String): Int {
        val products = ExchangeMapper.parseNomenclature(json)
        repository.replaceAllProducts(products)
        return products.size
    }

    private fun postJson(url: String, json: String): Boolean {
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        val b = Request.Builder().url(url).post(body)
        addAuth(b)
        return try {
            client.newCall(b.build()).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            Log.e("SyncManager", "POST", e); false
        }
    }

    private fun getJson(url: String): String? {
        val b = Request.Builder().url(url).get()
        addAuth(b)
        return try {
            client.newCall(b.build()).execute().use { if (it.isSuccessful) it.body?.string() else null }
        } catch (e: Exception) {
            Log.e("SyncManager", "GET", e); null
        }
    }

    private fun addAuth(builder: Request.Builder) {
        if (settings.httpLogin.isNotBlank()) {
            builder.header("Authorization", okhttp3.Credentials.basic(settings.httpLogin, settings.httpPassword))
        }
    }

    suspend fun exportDocuments(docs: List<Document>): String {
        return try {
            val f = exportDocumentsToFile(docs)
            val msg = "Выгрузка прошла успешно"
            AppLog.simple("$msg (${f.name}, док.: ${docs.size})")
            msg
        } catch (e: Exception) {
            val msg = "Выгрузка с ошибкой: ${e.message ?: e.javaClass.simpleName}"
            AppLog.simple(msg)
            msg
        }
    }

    suspend fun importNomenclature(): String {
        val n = importNomenclatureFromFile()
        return "Загружено: $n" + "\n" + "Папка: ${exchangeDirPath()}"
    }
}
