package ru.example.harvesterfree.util

import android.content.Context
import android.os.Environment
import android.util.Log
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Простой лог NEO.
 * - Всегда пишется (короткие события: синхронизация, ошибки, сканы).
 * - Обнуляется раз в сутки.
 * - Файл: …/NEO/neo_simple.log
 * - Подробный logcat-лог по-прежнему через enableLogging → neo.log
 */
object AppLog {
    @Volatile private var enabled = false
    @Volatile private var logFile: File? = null
    @Volatile private var simpleLogFile: File? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    @Volatile private var simpleLogDay: String = ""

    fun init(context: Context, enable: Boolean) {
        enabled = enable
        val appCtx = context.applicationContext
        executor.execute {
            try {
                if (enable) {
                    logFile = resolveLogFile(appCtx, "neo.log")
                    i("AppLog", "Logging ON → ${logFile?.absolutePath}")
                } else {
                    logFile = null
                }
                simpleLogFile = resolveLogFile(appCtx, "neo_simple.log")
                rotateSimpleLogIfNeeded()
            } catch (e: Exception) {
                Log.w("AppLog", "init: ${e.message}")
            }
        }
    }

    fun setEnabled(context: Context, enable: Boolean) {
        enabled = enable
        if (!enable) {
            logFile = null
            return
        }
        val appCtx = context.applicationContext
        executor.execute {
            try {
                logFile = resolveLogFile(appCtx, "neo.log")
                Log.i("AppLog", "Logging ON → ${logFile?.absolutePath}")
            } catch (e: Exception) {
                Log.w("AppLog", "setEnabled: ${e.message}")
            }
        }
    }

    fun isEnabled(): Boolean = enabled

    fun logFilePath(): String = logFile?.absolutePath ?: ""

    /** Путь к простому логу (для кнопки «Выгрузить логи»). */
    fun simpleLogFilePath(): String = simpleLogFile?.absolutePath ?: ""

    fun simpleLogFile(context: Context): File {
        simpleLogFile?.let { return it }
        val f = resolveLogFile(context.applicationContext, "neo_simple.log")
        simpleLogFile = f
        return f
    }

    /** Копия логов в указанную папку (или в Documents/NEO). Возвращает путь. */
    fun exportLogs(context: Context, targetDir: File? = null): String {
        val dir = targetDir ?: File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir,
            "NEO"
        )
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(dir, "neo_logs_$stamp.txt")
        val sb = StringBuilder()
        sb.appendLine("=== NEO logs export $stamp ===")
        val simple = simpleLogFile(context)
        if (simple.exists()) {
            sb.appendLine("--- simple log (${simple.absolutePath}) ---")
            sb.appendLine(simple.readText())
        }
        logFile?.takeIf { it.exists() }?.let {
            sb.appendLine("--- detailed log (${it.absolutePath}) ---")
            sb.appendLine(it.readText())
        }
        out.writeText(sb.toString())
        simple("Логи выгружены: ${out.name}")
        return out.absolutePath
    }

    private fun resolveLogFile(context: Context, name: String): File {
        val dirs = listOf(
            File("/storage/emulated/0/NEO"),
            File(Environment.getExternalStorageDirectory(), "NEO"),
            File(context.getExternalFilesDir(null), "NEO")
        )
        for (dir in dirs) {
            try {
                if (!dir.exists()) dir.mkdirs()
                if (dir.exists() && dir.canWrite()) {
                    val f = File(dir, name)
                    if (!f.exists()) f.writeText("NEO log started\n")
                    return f
                }
            } catch (_: Exception) {}
        }
        val fallback = File(context.filesDir, name)
        if (!fallback.exists()) fallback.writeText("NEO log started\n")
        return fallback
    }

    private fun rotateSimpleLogIfNeeded() {
        val today = dayFmt.format(Date())
        if (simpleLogDay == today) return
        simpleLogDay = today
        val f = simpleLogFile ?: return
        try {
            // Если файл старше суток (по дате первой строки / lastModified) — обнулить
            val dayOfFile = dayFmt.format(Date(f.lastModified()))
            if (dayOfFile != today && f.exists() && f.length() > 0) {
                f.writeText("NEO simple log $today\n")
            } else if (!f.exists() || f.length() == 0L) {
                f.writeText("NEO simple log $today\n")
            }
        } catch (_: Exception) {}
    }

    /** Простая запись (всегда). */
    fun simple(msg: String) {
        val line = "${fmt.format(Date())} $msg"
        Log.i("NEO", msg)
        executor.execute {
            try {
                rotateSimpleLogIfNeeded()
                val f = simpleLogFile ?: return@execute
                FileWriter(f, true).use { it.append(line).append('\n') }
            } catch (_: Exception) {}
        }
    }

    fun i(tag: String, msg: String) = write("I", tag, msg)
    fun w(tag: String, msg: String) = write("W", tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) {
        write("E", tag, msg + (t?.let { " | ${it.message}" } ?: ""))
        simple("ERR $tag: $msg")
    }

    private fun write(level: String, tag: String, msg: String) {
        when (level) {
            "I" -> Log.i(tag, msg)
            "W" -> Log.w(tag, msg)
            else -> Log.e(tag, msg)
        }
        if (!enabled) return
        val line = "${fmt.format(Date())} $level/$tag: $msg"
        executor.execute {
            try {
                val f = logFile ?: return@execute
                FileWriter(f, true).use { it.append(line).append('\n') }
            } catch (_: Exception) {}
        }
    }
}
