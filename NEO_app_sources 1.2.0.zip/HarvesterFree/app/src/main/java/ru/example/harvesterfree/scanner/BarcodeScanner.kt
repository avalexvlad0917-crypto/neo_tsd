package ru.example.harvesterfree.scanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import ru.example.harvesterfree.util.AppLog
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Newland / NEO SL40 — официальный handbook:
 *   EXTRA_SCAN_MODE:
 *     1 = Fill in EditText
 *     2 = Simulate keystroke (Keyboard)
 *     3 = Output via API (Broadcast)  ← нужен этот
 *
 * Broadcast: nlscan.action.SCANNER_RESULT
 * Extra: SCAN_BARCODE1, SCAN_STATE (ok/fail)
 *
 * Ошибка в логе: ставили MODE=0 → сканер НЕ шлёт broadcast.
 */
class HardwareScannerManager(
    context: Context,
    private val onBarcode: (String) -> Unit
) {
    private val appContext = context.applicationContext
    private var receiver: BroadcastReceiver? = null
    private val registered = AtomicBoolean(false)
    private val lastEmitMs = AtomicLong(0)
    private val debounceMs = 200L
    private val mainHandler = Handler(Looper.getMainLooper())
    val keyWedge = KeyWedgeBuffer { emit(it) }

    private val possibleActions = listOf(
        // === NEO / эталон NEO NeoSDK (строки из APK) ===
        "scan.rcv.message",
        "scan.rcv.enter",
        "scan.rcv.barcode",
        "scan.rcv.data",
        "ACTION_SCAN_RCV_MSG",
        "ACTION_SCAN_RCV_ENTER",
        "ACTION_SCAN_RESULT_BROADCAST",
        "ACTION_SCAN_RESULT_INPUT",
        "com.android.scanner.broadcast",
        "scan.barcode.string",
        // === Newland handbook API ===
        "nlscan.action.SCANNER_RESULT",
        "nlscan.action.SCANNER_RESULT2",
        "nlscan.action.SCANNER_RESULT3",
        "ACTION_BARCODE_DATA",
        // === Прочие OEM ===
        "android.intent.ACTION_DECODE_DATA",
        "com.android.server.scannerservice.broadcast",
        "com.android.server.scannerservice.broadcast.s1",
        "com.scanner.broadcast",
        "com.barcode.sendBroadcast",
        "android.intent.action.SCANRESULT",
        "android.bld.scan.action.RESULT_BROADCAST",
        "com.symbol.datawedge.api.RESULT_ACTION",
        "com.honeywell.decode.intent.action.EDIT_DATA",
        "com.honeywell.aidc.action.ACTION_BARCODE_DATA",
        "urovo.rcv.message",
        "com.xcheng.scanner.action.BARCODE_DECODING_BROADCAST",
        "com.geenk.action.GET_SCANDATA",
        "ACTION_GEEK_GET_SCANDATA"
    )

    private val possibleExtras = listOf(
        // NeoSDK / Newland OEM
        "barcodeData",
        "barocode",
        "barcode",
        "SCAN_BARCODE1",
        "SCAN_BARCODE",
        "SCAN_BARCODE2",
        "scan.barcode.string",
        "scannerdata",
        "scanner_data",
        "data",
        "decode_data",
        "DATA",
        "data_string",
        "barcode_string",
        "BARCODE",
        "barcodeDataString",
        "value",
        "scan_data",
        "SCAN_DATA",
        "code",
        "CODE",
        "scanResult",
        "EXTRA_SCAN_DATA",
        "BARCODE_STRING_TAG",
        "BARCODE_DATA",
        "EXTRA_BARCODE_DECODING_DATA",
        "com.symbol.datawedge.data_string",
        "com.honeywell.decode.intent.action.DATA"
    )

    fun start() {
        stop()
        configureBroadcastMode()
        receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent == null) return
                val action = intent.action ?: ""
                AppLog.i(TAG, "RX action=$action keys=${intent.extras?.keySet()}")
                Log.i(TAG, "RX action=$action")

                val state = intent.getStringExtra("SCAN_STATE")
                    ?: intent.getStringExtra("scan_state")
                    ?: intent.getStringExtra("status")
                if (state != null) {
                    val s = state.trim().lowercase()
                    if (s in listOf("fail", "error", "cancel", "false", "0")) {
                        AppLog.i(TAG, "skip state=$state")
                        return
                    }
                }

                val code = extractBarcode(intent)
                if (code.isNullOrBlank()) {
                    val dump = intent.extras?.keySet()?.joinToString { k ->
                        "$k=${intent.extras?.get(k)}"
                    } ?: "no-extras"
                    AppLog.w(TAG, "empty barcode for $action dump=$dump")
                    return
                }
                emit(code)
            }
        }
        val filter = IntentFilter().apply {
            possibleActions.forEach { addAction(it) }
            priority = IntentFilter.SYSTEM_HIGH_PRIORITY
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                appContext.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                appContext.registerReceiver(receiver, filter)
            }
            registered.set(true)
            AppLog.i(TAG, "Receiver registered (${possibleActions.size} actions)")
        } catch (e: Exception) {
            AppLog.e(TAG, "register failed: ${e.message}")
            registered.set(false)
            receiver = null
        }
    }

    fun stop() {
        val r = receiver
        receiver = null
        if (r != null && registered.getAndSet(false)) {
            try { appContext.unregisterReceiver(r) } catch (_: Exception) {}
        }
    }

    private fun emit(code: String) {
        val now = System.currentTimeMillis()
        if (now - lastEmitMs.get() < debounceMs) return
        lastEmitMs.set(now)
        val t = code.trim().trimEnd('\n', '\r', '\t', '\u0000')
        if (t.isEmpty()) return
        AppLog.i(TAG, "EMIT: $t")
        Log.i(TAG, "EMIT: $t")
        mainHandler.post {
            try { onBarcode(t) } catch (e: Exception) {
                AppLog.e(TAG, "callback: ${e.message}")
            }
        }
    }

    private fun extractBarcode(intent: Intent): String? {
        for (key in possibleExtras) {
            try {
                intent.getStringExtra(key)?.takeIf { it.isNotBlank() }?.let { return it.trim() }
            } catch (_: Exception) {}
            try {
                val bytes = intent.getByteArrayExtra(key)
                if (bytes != null && bytes.isNotEmpty()) {
                    val s = String(bytes, Charsets.UTF_8).trim { it <= ' ' || it == '\u0000' }
                    if (s.isNotBlank()) return s
                }
            } catch (_: Exception) {}
        }
        // length + barocode pattern
        try {
            val len = intent.getIntExtra("length", -1)
            val bytes = intent.getByteArrayExtra("barocode")
                ?: intent.getByteArrayExtra("barcode")
            if (bytes != null && bytes.isNotEmpty()) {
                val n = if (len > 0 && len <= bytes.size) len else bytes.size
                return String(bytes, 0, n).trim { it <= ' ' || it == '\u0000' }
            }
        } catch (_: Exception) {}

        intent.extras?.keySet()?.forEach { key ->
            if (key.contains("state", true) || key.contains("type", true) ||
                key.contains("length", true) || key.contains("sound", true)
            ) return@forEach
            when (val v = intent.extras?.get(key)) {
                is String -> if (v.length in 3..512) return v.trim()
                is ByteArray -> if (v.isNotEmpty()) {
                    val s = String(v).trim { it <= ' ' || it == '\u0000' }
                    if (s.length in 3..512) return s
                }
            }
        }
        return null
    }

    /**
     * Newland handbook: EXTRA_SCAN_MODE = 3 → Output via API (broadcast).
     * 1 = EditText, 2 = Keyboard. Значение 0 НЕ является Broadcast.
     */
    /**
     * Настройка режима вывода по строкам из эталонного APK + handbook Newland.
     * Шлём несколько вариантов — прошивки NEO/Newland различаются.
     */
    private fun configureBroadcastMode() {
        val configs = listOf(
            // 1) Классический Newland handbook: mode 3 = API/Broadcast
            Intent("ACTION_BAR_SCANCFG").apply {
                putExtra("EXTRA_SCAN_POWER", 1)
                putExtra("EXTRA_SCAN_MODE", 3)
                putExtra("EXTRA_SCAN_AUTOENT", 0)
                putExtra("EXTRA_SCAN_NOTY_SND", 1)
            },
            // 2) Эталон NEO: ACTION_SCAN_SERVICE_SETTINGS + SCAN_OUTPUTMODE_BROADCAST
            Intent("ACTION_SCAN_SERVICE_SETTINGS").apply {
                putExtra("SCAN_OUTPUTMODE", "SCAN_OUTPUTMODE_BROADCAST")
                putExtra("SCAN_OUTPUTMODE_BROADCAST", 1)
                putExtra("OUTPUT_MODE", 0)
                putExtra("barcodeOutputMode", 0)
            },
            Intent("ACTION_SCAN_SETTINGS").apply {
                putExtra("SCAN_OUTPUTMODE", 0)
                putExtra("EXTRA_SCAN_MODE", 3)
            },
            Intent("ACTION_SCAN_SERVICE_ENABLE_SETTINGS").apply {
                putExtra("SCAN_OUTPUTMODE", 0)
            },
            Intent("nlscan.action.SCANNER_SETTINGS").apply {
                putExtra("EXTRA_SCAN_MODE", 3)
                putExtra("EXTRA_SCAN_POWER", 1)
            },
            // 3) Старт сервиса сканера (эталон)
            Intent("ACTION_SCAN_SERVICE_START"),
            Intent("scan.service.startup"),
            // 4) Включить сканер
            Intent("ACTION_SCAN_ENABLED").apply {
                putExtra("EXTRA_ENABLED", true)
            }
        )
        for (i in configs) {
            try {
                appContext.sendBroadcast(i)
            } catch (e: Exception) {
                AppLog.w(TAG, "config ${i.action}: ${e.message}")
            }
        }
        AppLog.i(TAG, "Scanner config: MODE=3 + SCAN_OUTPUTMODE_BROADCAST + service start")
    }

    companion object {
        private const val TAG = "NeoScanner"
    }
}

class KeyWedgeBuffer(private val onComplete: (String) -> Unit) {
    private val sb = StringBuilder()
    private val handler = Handler(Looper.getMainLooper())
    private val flushRunnable = Runnable { flush() }

    fun onKey(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        val ch = event.unicodeChar
        when {
            event.keyCode == KeyEvent.KEYCODE_ENTER ||
                event.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                event.keyCode == KeyEvent.KEYCODE_TAB -> {
                flush(); return true
            }
            ch in 32..126 -> {
                sb.append(ch.toChar())
                handler.removeCallbacks(flushRunnable)
                handler.postDelayed(flushRunnable, 60L)
                return true
            }
            else -> return false
        }
    }

    private fun flush() {
        handler.removeCallbacks(flushRunnable)
        if (sb.isEmpty()) return
        val code = sb.toString(); sb.clear()
        if (code.isNotBlank()) onComplete(code)
    }
}

@Composable
fun CameraBarcodeScanner(
    onBarcodeDetected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val scanner = remember { BarcodeScanning.getClient() }
    var lastCode by remember { mutableStateOf("") }
    var lastTime by remember { mutableStateOf(0L) }
    DisposableEffect(Unit) {
        onDispose { try { scanner.close() } catch (_: Exception) {} }
    }
    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build().also { ia ->
                        ia.setAnalyzer(executor) { imageProxy ->
                            processImageProxy(scanner, imageProxy) { barcode ->
                                val now = System.currentTimeMillis()
                                if (barcode != lastCode || now - lastTime > 1500) {
                                    lastCode = barcode; lastTime = now
                                    onBarcodeDetected(barcode)
                                }
                            }
                        }
                    }
                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                    )
                } catch (e: Exception) {
                    Log.e("CameraScanner", "bind", e)
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        modifier = modifier.fillMaxSize()
    )
}

@androidx.annotation.OptIn(ExperimentalGetImage::class)
private fun processImageProxy(
    scanner: com.google.mlkit.vision.barcode.BarcodeScanner,
    imageProxy: ImageProxy,
    onSuccess: (String) -> Unit
) {
    val mediaImage = imageProxy.image
    if (mediaImage != null) {
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { b -> b.firstOrNull()?.rawValue?.let { onSuccess(it) } }
            .addOnCompleteListener { imageProxy.close() }
    } else imageProxy.close()
}
