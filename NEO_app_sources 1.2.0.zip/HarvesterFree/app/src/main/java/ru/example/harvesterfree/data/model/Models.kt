package ru.example.harvesterfree.data.model

import androidx.room.*
import java.math.BigDecimal
import java.util.UUID

enum class DocumentType {
    RECEIPT,              // Приёмка
    SHIPMENT,             // Отгрузка
    INVENTORY,            // Инвентаризация
    WRITE_OFF,            // Списание
    MOVEMENT,             // Перемещение
    CUSTOMER_ORDER,       // Заказ клиента
    SERIAL_COLLECTION,    // Сбор серийных номеров (автономный)
    // Ордерная схема (УТ 11 / КА) — в меню создания при configId=UT11
    GOODS_RECEIPT_ORDER,  // Приходный ордер на товары
    GOODS_ISSUE_ORDER,    // Расходный ордер на товары
    MOVEMENT_ORDER,       // Ордер на перемещение
    SURPLUS_ORDER,        // Ордер на отражение излишков
    SHORTAGE_ORDER,       // Ордер на отражение недостач
    DAMAGE_ORDER,         // Ордер на отражение порчи
    PURCHASE_ORDER,       // Заказ поставщику
    MOVEMENT_REQUEST      // Заказ на перемещение
}

/** Ордерные / заказные типы УТ, где на ТСД всегда запрашиваем серийные номера. */
fun DocumentType.requiresFactorySerials(): Boolean = when (this) {
    DocumentType.GOODS_RECEIPT_ORDER,
    DocumentType.GOODS_ISSUE_ORDER,
    DocumentType.MOVEMENT_ORDER,
    DocumentType.SURPLUS_ORDER,
    DocumentType.SHORTAGE_ORDER,
    DocumentType.DAMAGE_ORDER,
    DocumentType.PURCHASE_ORDER,
    DocumentType.MOVEMENT_REQUEST -> true
    else -> false
}

/** Типы документов для меню «Создать» в зависимости от configId 1С. */
fun documentTypesForConfig(configId: String): List<DocumentType> {
    val base = listOf(
        DocumentType.RECEIPT,
        DocumentType.SHIPMENT,
        DocumentType.INVENTORY,
        DocumentType.WRITE_OFF,
        DocumentType.MOVEMENT,
        DocumentType.CUSTOMER_ORDER,
        DocumentType.SERIAL_COLLECTION
    )
    val orderScheme = listOf(
        DocumentType.GOODS_RECEIPT_ORDER,
        DocumentType.GOODS_ISSUE_ORDER,
        DocumentType.MOVEMENT_ORDER,
        DocumentType.SURPLUS_ORDER,
        DocumentType.SHORTAGE_ORDER,
        DocumentType.DAMAGE_ORDER,
        DocumentType.PURCHASE_ORDER,
        DocumentType.MOVEMENT_REQUEST
    )
    val id = configId.trim().uppercase()
    return if (id == "UT11" || id == "ERP") base + orderScheme else base
}

enum class DocumentStatus {
    DRAFT, READY, SENT, CANCELLED
}

enum class VatRate(val label: String, val value: Double) {
    NO_VAT("Без НДС", 0.0),
    VAT_0("0%", 0.0),
    VAT_10("10%", 10.0),
    VAT_20("20%", 20.0),
    VAT_22("22%", 22.0);

    companion object {
        fun fromLabel(s: String?): VatRate =
            entries.find { it.label == s || it.name == s } ?: NO_VAT
    }
}

enum class NomenclatureKind(val label: String) {
    GOODS("Товар"),
    SERVICE("Услуга"),
    MATERIAL("Материал"),
    OTHER("Прочее");

    companion object {
        fun fromLabel(s: String?): NomenclatureKind =
            entries.find { it.label == s || it.name == s } ?: GOODS
    }
}

enum class MarkedProductType(val label: String) {
    NONE("Не маркируется"),
    SHOES("Обувь"),
    CLOTHES("Одежда"),
    TOBACCO("Табак"),
    MILK("Молоко"),
    WATER("Вода"),
    BEER("Пиво"),
    PERFUME("Парфюмерия"),
    TIRES("Шины"),
    PHOTO("Фототехника"),
    MEDICAL("Медизделия"),
    OTHER("Прочее маркируемое");

    companion object {
        fun fromLabel(s: String?): MarkedProductType =
            entries.find { it.label == s || it.name == s } ?: NONE
    }
}

/** Видимые столбцы в документах */
enum class DocumentColumn {
    NAME, BARCODE, QUANTITY, UNIT, PRICE, AMOUNT, SERIALS, MARKS
}

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val barcode: String,
    val name: String,
    val unit: String = "шт",
    val hasSerials: Boolean = false,
    val article: String? = null,
    val price: Double? = null, // стоимость (цена) из 1С, по умолчанию 0
    val isMarked: Boolean = false,
    val gtin: String? = null,
    val kind: String = NomenclatureKind.GOODS.name,
    val markedType: String = MarkedProductType.NONE.name,
    val vatRate: String = VatRate.NO_VAT.label
)

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val type: DocumentType,
    val number: String,
    val date: Long = System.currentTimeMillis(),
    val status: DocumentStatus = DocumentStatus.DRAFT,
    val comment: String? = null,
    val organizationId: String? = null,
    val organizationName: String? = null,
    val warehouseId: String? = null,
    val warehouseName: String? = null
)

@Entity(tableName = "organizations")
data class Organization(
    @PrimaryKey val id: String,
    val name: String
)

@Entity(tableName = "warehouses")
data class Warehouse(
    @PrimaryKey val id: String,
    val name: String
)

@Entity(
    tableName = "document_lines",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("documentId")]
)
data class DocumentLineEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val documentId: String,
    val productId: String?,
    val barcode: String,
    val productName: String,
    val quantity: Double,
    val unit: String = "шт",
    val price: Double = 0.0,   // стоимость за единицу
    val amount: Double = 0.0,  // сумма = quantity * price
    val serialsJson: String = "[]",
    val marksJson: String = "[]"
)

data class DocumentWithLines(
    @Embedded val document: DocumentEntity,
    @Relation(parentColumn = "id", entityColumn = "documentId")
    val lines: List<DocumentLineEntity>
)

data class DocumentLine(
    val id: String = UUID.randomUUID().toString(),
    val barcode: String,
    val productName: String,
    val quantity: BigDecimal,
    val unit: String = "шт",
    val price: BigDecimal = BigDecimal.ZERO,
    val amount: BigDecimal = BigDecimal.ZERO,
    val serials: List<String> = emptyList(),
    val marks: List<String> = emptyList(),
    val productId: String? = null
)

data class Document(
    val id: String = UUID.randomUUID().toString(),
    val type: DocumentType,
    val number: String,
    val date: Long = System.currentTimeMillis(),
    val status: DocumentStatus = DocumentStatus.DRAFT,
    val lines: List<DocumentLine> = emptyList(),
    val comment: String? = null,
    val organizationId: String? = null,
    val organizationName: String? = null,
    val warehouseId: String? = null,
    val warehouseName: String? = null
) {
    /** Для SERIAL_COLLECTION строки — это сами номера в serials первой «логической» строки или отдельные lines */
    fun isSerialCollection(): Boolean = type == DocumentType.SERIAL_COLLECTION
    fun isAutonomous(): Boolean = type == DocumentType.SERIAL_COLLECTION
}

data class ParsedCode(
    val raw: String,
    val type: CodeType,
    val gtin: String? = null,
    val serial: String? = null,
    val fullMark: String? = null,
    val cryptoTail: String? = null
)

enum class CodeType {
    EAN13, EAN8, CODE128, DATAMATRIX_MARK, DATAMATRIX_OTHER, UNKNOWN
}
