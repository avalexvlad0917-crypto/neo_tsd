package ru.example.harvesterfree.sync

import com.google.gson.GsonBuilder
import com.google.gson.annotations.SerializedName
import ru.example.harvesterfree.data.model.Document
import ru.example.harvesterfree.data.model.DocumentLine
import ru.example.harvesterfree.data.model.DocumentStatus
import ru.example.harvesterfree.data.model.DocumentType
import ru.example.harvesterfree.data.model.Product
import ru.example.harvesterfree.util.AppLog
import java.text.SimpleDateFormat
import java.util.*

data class ExchangeDocument(
    @SerializedName("id") val id: String? = null,
    @SerializedName("type") val type: String? = null,
    @SerializedName("sourceDocument") val sourceDocument: String? = null,
    @SerializedName("number") val number: String? = null,
    @SerializedName("date") val date: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("comment") val comment: String? = null,
    @SerializedName("organization") val organization: String? = null,
    @SerializedName("organizationId") val organizationId: String? = null,
    @SerializedName("warehouse") val warehouse: String? = null,
    @SerializedName("warehouseId") val warehouseId: String? = null,
    @SerializedName("warehouseFrom") val warehouseFrom: String? = null,
    @SerializedName("warehouseTo") val warehouseTo: String? = null,
    @SerializedName("lines") val lines: List<ExchangeLine>? = null
)

data class CatalogsPackage(
    @SerializedName("version") val version: String? = null,
    @SerializedName("configId") val configId: String? = null,
    @SerializedName("organizations") val organizations: List<CatalogItem>? = null,
    @SerializedName("warehouses") val warehouses: List<CatalogItem>? = null
)

data class CatalogItem(
    @SerializedName("id") val id: String?,
    @SerializedName("name") val name: String?
)

data class ExchangeLine(
    @SerializedName("barcode") val barcode: String? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("quantity") val quantity: Double? = 0.0,
    @SerializedName("unit") val unit: String? = "шт",
    @SerializedName("price") val price: Double? = 0.0,
    @SerializedName("amount") val amount: Double? = 0.0,
    @SerializedName("serials") val serials: List<String>? = null,
    @SerializedName("marks") val marks: List<String>? = null,
    @SerializedName("article") val article: String? = null
)

data class ExchangePackage(
    @SerializedName("configId") val configId: String? = null,
    @SerializedName("version") val version: String = "1.2",
    @SerializedName("deviceId") val deviceId: String,
    @SerializedName("timestamp") val timestamp: String,
    @SerializedName("documents") val documents: List<ExchangeDocument>
)

data class NomenclatureItem(
    @SerializedName("id") val id: String? = null,
    @SerializedName("barcode") val barcode: String,
    @SerializedName("name") val name: String,
    @SerializedName("unit") val unit: String? = "шт",
    @SerializedName("article") val article: String? = null,
    @SerializedName("price") val price: Double? = null,
    @SerializedName("hasSerials") val hasSerials: Boolean? = false,
    @SerializedName("isMarked") val isMarked: Boolean? = false,
    @SerializedName("gtin") val gtin: String? = null,
    @SerializedName("kind") val kind: String? = null,
    @SerializedName("markedType") val markedType: String? = null,
    @SerializedName("vatRate") val vatRate: String? = null
)

data class NomenclaturePackage(
    @SerializedName("version") val version: String? = "1.0",
    @SerializedName("configId") val configId: String? = null,
    @SerializedName("timestamp") val timestamp: String? = null,
    @SerializedName("items") val items: List<NomenclatureItem>
)

object ExchangeMapper {
    private val gson = GsonBuilder().setPrettyPrinting().create()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())

    fun documentsToJson(docs: List<Document>, deviceId: String): String {
        // SERIAL_COLLECTION не выгружаем в 1С
        val exportable = docs.filter { it.type != DocumentType.SERIAL_COLLECTION }
        val package_ = ExchangePackage(
            deviceId = deviceId,
            timestamp = dateFormat.format(Date()),
            documents = exportable.map { doc ->
                ExchangeDocument(
                    id = doc.id,
                    type = doc.type.name,
                    number = doc.number,
                    date = dateFormat.format(Date(doc.date)),
                    status = doc.status.name,
                    comment = doc.comment,
                    organization = doc.organizationName,
                    organizationId = doc.organizationId,
                    warehouse = doc.warehouseName,
                    warehouseId = doc.warehouseId,
                    lines = doc.lines.map { line ->
                        ExchangeLine(
                            barcode = line.barcode,
                            name = line.productName,
                            quantity = line.quantity.toDouble(),
                            unit = line.unit,
                            price = line.price.toDouble(),
                            amount = line.amount.toDouble(),
                            serials = line.serials,
                            marks = line.marks
                        )
                    }
                )
            }
        )
        return gson.toJson(package_)
    }

    
    fun parseDocuments(json: String): List<Document> {
        val pkg = gson.fromJson(json, ExchangePackage::class.java)
        val docs = pkg.documents ?: return emptyList()
        return docs.mapNotNull { ed ->
            val type = resolveDocumentType(ed.type, ed.sourceDocument)
                ?: run {
                    AppLog.w("ExchangeMapper", "unknown type ${ed.type} / ${ed.sourceDocument}")
                    return@mapNotNull null
                }
            val status = try {
                DocumentStatus.valueOf((ed.status ?: "DRAFT").trim().uppercase())
            } catch (_: Exception) {
                DocumentStatus.DRAFT
            }
            val dateMs = try {
                dateFormat.parse(ed.date ?: "")?.time ?: System.currentTimeMillis()
            } catch (_: Exception) {
                System.currentTimeMillis()
            }
            Document(
                id = ed.id?.ifBlank { null } ?: java.util.UUID.randomUUID().toString(),
                type = type,
                number = ed.number?.ifBlank { null } ?: type.name,
                date = dateMs,
                status = status,
                comment = ed.comment,
                organizationId = ed.organizationId,
                organizationName = ed.organization ?: ed.organizationId,
                warehouseId = ed.warehouseId,
                warehouseName = ed.warehouse ?: ed.warehouseFrom,
                lines = (ed.lines ?: emptyList()).map { line ->
                    val qty = (line.quantity ?: 0.0).toBigDecimal()
                    val price = (line.price ?: 0.0).toBigDecimal()
                    val amountVal = line.amount ?: 0.0
                    DocumentLine(
                        barcode = line.barcode.orEmpty(),
                        productName = line.name.orEmpty(),
                        quantity = qty,
                        unit = line.unit?.ifBlank { "шт" } ?: "шт",
                        price = price,
                        amount = if (amountVal != 0.0) amountVal.toBigDecimal() else price * qty,
                        serials = line.serials ?: emptyList(),
                        marks = line.marks ?: emptyList(),
                        productId = null
                    )
                }
            )
        }
    }

    fun parseCatalogs(json: String): Pair<List<ru.example.harvesterfree.data.model.Organization>, List<ru.example.harvesterfree.data.model.Warehouse>> {
        val pkg = gson.fromJson(json, CatalogsPackage::class.java)
        val orgs = (pkg.organizations ?: emptyList()).mapNotNull { item ->
            val id = item.id?.trim().orEmpty()
            val name = item.name?.trim().orEmpty()
            if (id.isEmpty() && name.isEmpty()) null
            else ru.example.harvesterfree.data.model.Organization(
                id = id.ifEmpty { name },
                name = name.ifEmpty { id }
            )
        }
        val whs = (pkg.warehouses ?: emptyList()).mapNotNull { item ->
            val id = item.id?.trim().orEmpty()
            val name = item.name?.trim().orEmpty()
            if (id.isEmpty() && name.isEmpty()) null
            else ru.example.harvesterfree.data.model.Warehouse(
                id = id.ifEmpty { name },
                name = name.ifEmpty { id }
            )
        }
        return orgs to whs
    }

    fun parseNomenclature(json: String): List<Product> {
        val pkg = gson.fromJson(json, NomenclaturePackage::class.java)
        return pkg.items.map { item ->
            Product(
                id = item.id ?: java.util.UUID.randomUUID().toString(),
                barcode = item.barcode,
                name = item.name,
                unit = item.unit ?: "шт",
                article = item.article,
                price = item.price ?: 0.0,
                hasSerials = item.hasSerials ?: false,
                isMarked = item.isMarked ?: false,
                gtin = item.gtin,
                kind = item.kind ?: "GOODS",
                markedType = item.markedType ?: "NONE",
                vatRate = item.vatRate ?: "Без НДС"
            )
        }
    }

    /** Маппинг type/sourceDocument 1С → DocumentType. */
    fun resolveDocumentType(type: String?, sourceDocument: String? = null): DocumentType? {
        val src = sourceDocument?.trim().orEmpty()
        if (src.isNotEmpty()) {
            when (src) {
                "ПриходныйОрдерНаТовары" -> return DocumentType.GOODS_RECEIPT_ORDER
                "РасходныйОрдерНаТовары" -> return DocumentType.GOODS_ISSUE_ORDER
                "ОрдерНаПеремещениеТоваров" -> return DocumentType.MOVEMENT_ORDER
                "ОрдерНаОтражениеИзлишковТоваров" -> return DocumentType.SURPLUS_ORDER
                "ОрдерНаОтражениеНедостачТоваров" -> return DocumentType.SHORTAGE_ORDER
                "ОрдерНаОтражениеПорчиТоваров" -> return DocumentType.DAMAGE_ORDER
                "ЗаказПоставщику" -> return DocumentType.PURCHASE_ORDER
                "ЗаказНаПеремещение" -> return DocumentType.MOVEMENT_REQUEST
            }
        }
        val t = type?.trim()?.uppercase().orEmpty()
        if (t.isEmpty()) return null
        // Прямое совпадение с enum
        try {
            return DocumentType.valueOf(t)
        } catch (_: Exception) { }
        // Синонимы type из 1С (короткие коды)
        return when (t) {
            "RECEIPT" -> DocumentType.RECEIPT
            "SHIPMENT" -> DocumentType.SHIPMENT
            "INVENTORY" -> DocumentType.INVENTORY
            "WRITE_OFF", "WRITEOFF" -> DocumentType.WRITE_OFF
            "MOVEMENT" -> DocumentType.MOVEMENT
            "CUSTOMER_ORDER", "ORDER" -> DocumentType.CUSTOMER_ORDER
            "GOODS_RECEIPT_ORDER" -> DocumentType.GOODS_RECEIPT_ORDER
            "GOODS_ISSUE_ORDER" -> DocumentType.GOODS_ISSUE_ORDER
            "MOVEMENT_ORDER" -> DocumentType.MOVEMENT_ORDER
            "SURPLUS_ORDER" -> DocumentType.SURPLUS_ORDER
            "SHORTAGE_ORDER" -> DocumentType.SHORTAGE_ORDER
            "DAMAGE_ORDER" -> DocumentType.DAMAGE_ORDER
            "PURCHASE_ORDER" -> DocumentType.PURCHASE_ORDER
            "MOVEMENT_REQUEST" -> DocumentType.MOVEMENT_REQUEST
            else -> null
        }
    }

    fun extractConfigId(json: String): String? {
        return try {
            val tree = gson.fromJson(json, com.google.gson.JsonObject::class.java)
            tree.get("configId")?.asString?.takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

}
